export const HUD_STRINGS = {
    ru: {
        weapons: { knife: 'Нож', bow: 'Лук', laser: 'Лазер', shotgun: 'Дробовик', flamethrower: 'Огнемёт', pistol: 'Пистолет', rifle: 'Винтовка', machinegun: 'Пулемет', bazooka: 'Базука' },
        perkOptions: {
            quickHands: { label: 'Быстрые руки', desc: 'Сильно ускоряет атаки и использование оружия ближнего боя.' },
            silentStep: { label: 'Тихий шаг', desc: 'Почти убирает шум шагов и делает тебя заметно тише.' },
            moreAmmo: { label: 'Больше патронов', desc: 'Сильно увеличивает запас патронов и прочность оружия.' },
            fastRun: { label: 'Быстрый бег', desc: 'Заметно повышает скорость перемещения весь матч.' },
            thickSkin: { label: 'Плотная кожа', desc: 'Снижает входящий урон и дает больше шансов выжить.' },
            steadyAim: { label: 'Стабильный прицел', desc: 'Сильно режет отдачу и упрощает стрельбу.' },
            autoFire: { label: 'AUTO FIRE', desc: 'Автоматически стреляет по цели, когда прицел наведен на врага.' }
        },
        killRewardHint: 'Выберите одну награду за серию убийств',
        pauseKeyInfo: 'M - ПАУЗА',
        pauseTitle: 'Пауза',
        pauseControls: 'WASD - движение · Мышь - обзор · E - взаимодействие · Space - прыжок · ЛКМ - атака · M - пауза',
        music: 'Музыка',
        effects: 'Эффекты',
        sensitivity: 'Чувствительность',
        keybindsHint: 'Управление (кликни, чтобы переназначить)',
        resume: 'Продолжить',
        editButtons: 'Настроить кнопки',
        resetSettings: 'Сбросить настройки',
        pauseHint: 'Перетащи кнопки управления, чтобы расположить их удобнее.',
        perkButton: 'ПЕРК ДО СТАРТА',
        perkTitle: 'Выбор перка',
        perkDesc: 'Перк выбирается один раз перед матчем и действует весь раунд.',
        perkPrev: 'Назад',
        perkNext: 'Вперёд',
        perkSelect: 'Выбрать перк',
        scoreboardTitle: 'Итоги раунда',
        keybinds: { KeyW: 'Вперёд', KeyS: 'Назад', KeyA: 'Влево', KeyD: 'Вправо', Space: 'Прыжок', KeyE: 'Взаимодействие', MouseLeft: 'Атака', KeyP: 'Меню перков' },
        gameOverTitle: 'Игра окончена',
        gameOverPlace: (place, kills) => `Место: ${place} · Убийства: ${kills}`,
        gameOverRecord: (place, kills) => `Рекорд: ${place}-е место · ${kills} убийств`,
        newRecord: 'Новый рекорд!',
        killRewardTitle: (kills) => `Серия: ${kills} убийств`,
        killRewardButton: (kills) => `Награда за ${kills} убийств`,
        perkLabel: (label) => `Перк: ${label}`
    },
    en: {
        weapons: { knife: 'Knife', bow: 'Bow', laser: 'Laser', shotgun: 'Shotgun', flamethrower: 'Flamethrower', pistol: 'Pistol', rifle: 'Rifle', machinegun: 'MG', bazooka: 'Bazooka' },
        perkOptions: {
            quickHands: { label: 'Quick Hands', desc: 'Greatly speeds up attacks and melee weapon usage.' },
            silentStep: { label: 'Silent Step', desc: 'Almost removes footstep noise and makes you much quieter.' },
            moreAmmo: { label: 'More Ammo', desc: 'Greatly increases ammo reserve and weapon durability.' },
            fastRun: { label: 'Fast Run', desc: 'Noticeably increases movement speed for the whole match.' },
            thickSkin: { label: 'Thick Skin', desc: 'Reduces incoming damage and improves your chances to survive.' },
            steadyAim: { label: 'Steady Aim', desc: 'Greatly reduces recoil and makes shooting easier.' },
            autoFire: { label: 'AUTO FIRE', desc: 'Automatically fires at the target when the aim is on an enemy.' }
        },
        killRewardHint: 'Choose one reward for your kill streak',
        pauseKeyInfo: 'M - PAUSE',
        pauseTitle: 'Pause',
        pauseControls: 'WASD - move · Mouse - look · E - interact · Space - jump · LMB - attack · M - pause',
        music: 'Music',
        effects: 'Effects',
        sensitivity: 'Sensitivity',
        keybindsHint: 'Controls (click to rebind)',
        resume: 'Resume',
        editButtons: 'Edit buttons',
        resetSettings: 'Reset settings',
        pauseHint: 'Drag the control buttons to place them where you like.',
        perkButton: 'PRE-MATCH PERK',
        perkTitle: 'Perk selection',
        perkDesc: 'The perk is chosen once before the match and lasts the whole round.',
        perkPrev: 'Back',
        perkNext: 'Next',
        perkSelect: 'Select perk',
        scoreboardTitle: 'Round results',
        keybinds: { KeyW: 'Forward', KeyS: 'Back', KeyA: 'Left', KeyD: 'Right', Space: 'Jump', KeyE: 'Interact', MouseLeft: 'Attack', KeyP: 'Perk menu' },
        gameOverTitle: 'Game Over',
        gameOverPlace: (place, kills) => `Place: ${place} · Kills: ${kills}`,
        gameOverRecord: (place, kills) => `Record: ${place}th place · ${kills} kills`,
        newRecord: 'New record!',
        killRewardTitle: (kills) => `Streak: ${kills} kills`,
        killRewardButton: (kills) => `Reward for ${kills} kills`,
        perkLabel: (label) => `Perk: ${label}`
    }
};

export class HUD {
    static ICON_MAP = { knife: 'KNF', bow: 'BOW', laser: 'LAS', shotgun: 'SG', flamethrower: 'FIRE', pistol: 'PST', rifle: 'RIF', machinegun: 'MG', bazooka: 'BAZ' };
    static AMMO_NAME_MAP = HUD_STRINGS.ru.weapons;
    constructor() {
        this.perkPanelLocked = false;
        this._el = {};
        this._lastState = { healthPercent: -1, armorPercent: -1, playersCount: -1, ammoText: '', selectedSlot: -1, slotTypes: [] };
        this.lang = 'ru';
        this.t = HUD_STRINGS.ru;
        this.perkOptions = Object.keys(HUD_STRINGS.ru.perkOptions).map((value) => ({
            value,
            label: HUD_STRINGS.ru.perkOptions[value].label,
            desc: HUD_STRINGS.ru.perkOptions[value].desc
        }));
        this.createHUD();
    }

    setLang(lang) {
        const next = HUD_STRINGS[lang] ? lang : 'ru';
        if (next === this.lang) return;
        this.lang = next;
        this.t = HUD_STRINGS[next];
        this.applyStaticStrings();
    }

    applyStaticStrings() {
        const t = this.t;
        const set = (id, text) => {
            const el = this.root ? this.root.querySelector('#' + id) : null;
            if (el && typeof text === 'string') el.textContent = text;
        };
        set('pauseKeyInfo', t.pauseKeyInfo);
        set('killRewardHint', t.killRewardHint);
        set('pauseTitleText', t.pauseTitle);
        set('pauseControlsText', t.pauseControls);
        set('pauseMusicLabel', t.music);
        set('pauseSfxLabel', t.effects);
        set('pauseSensLabel', t.sensitivity);
        set('keybindsHintText', t.keybindsHint);
        set('pauseResume', t.resume);
        set('pauseEdit', t.editButtons);
        set('pauseResetSettings', t.resetSettings);
        set('pauseHint', t.pauseHint);
        set('perkButton', t.perkButton);
        set('perkTitle', t.perkTitle);
        set('perkDesc', t.perkDesc);
        set('perkPrev', t.perkPrev);
        set('perkNext', t.perkNext);
        set('perkSelectMobile', t.perkSelect);
        set('scoreboardTitle', t.scoreboardTitle);
        this.perkOptions.forEach((opt) => {
            const src = t.perkOptions[opt.value];
            if (src) {
                opt.label = src.label;
                opt.desc = src.desc;
            }
        });
        this.perkButtons?.forEach((btn) => {
            const opt = this.perkOptions.find((o) => o.value === btn.getAttribute('data-perk'));
            if (opt) btn.textContent = opt.label;
        });
        if (this.keybindActions) {
            this.keybindActions.forEach((item) => {
                const label = t.keybinds[item.id];
                if (label) item.label = label;
            });
            this.renderKeybinds();
        }
    }

    getSlotDisplayNumber(slotIndex) {
        return ((slotIndex + 1) % 10).toString();
    }

    createHUD() {
        const isMobile = /Mobi|Android|iPhone|iPad|iPod/i.test(navigator.userAgent || '');
        this._isMobile = isMobile;
        const shortSide = Math.min(window.innerWidth, window.innerHeight);
        const scale = isMobile
            ? (shortSide < 420 ? 0.7 : shortSide < 600 ? 0.8 : 0.9)
            : 1;
        const px = (value) => Math.round(value * scale);

        const hud = document.createElement('div');
        hud.id = 'hud';
        hud.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 1000;
            font-family: 'Trebuchet MS', Verdana, sans-serif;
            color: #e9f0f6;
            text-shadow: 0 2px 0 rgba(0,0,0,0.35);
        `;
        const root = document.getElementById('gameRoot') || document.body;
        root.appendChild(hud);
        this.root = hud;
        // Hide HUD until game starts — shown via this.hud.show()
        this.root.style.display = 'none';

        const visionOverlay = document.createElement('div');
        visionOverlay.id = 'visionOverlay';
        visionOverlay.style.cssText = `
            position: absolute;
            inset: 0;
            pointer-events: none;
            z-index: 940;
            opacity: 0;
            transition: opacity 0.3s ease;
            background:
                linear-gradient(180deg, rgba(2,8,14,0.36) 0%, rgba(2,8,14,0.1) 18%, rgba(2,8,14,0.1) 82%, rgba(0,0,0,0.46) 100%),
                linear-gradient(90deg, rgba(0,0,0,0.44) 0%, rgba(0,0,0,0.06) 20%, rgba(0,0,0,0.06) 80%, rgba(0,0,0,0.44) 100%);
        `;
        hud.appendChild(visionOverlay);

        const lootFeed = document.createElement('div');
        lootFeed.id = 'lootFeed';
        lootFeed.style.cssText = `
            position: absolute;
            top: ${px(78)}px;
            right: ${px(16)}px;
            display: flex;
            flex-direction: column;
            gap: ${px(8)}px;
            max-width: min(${px(280)}px, 72vw);
            z-index: 1350;
            pointer-events: none;
        `;
        hud.appendChild(lootFeed);

        const killReward = document.createElement('button');
        killReward.id = 'killReward';
        killReward.type = 'button';
        killReward.style.cssText = `
            position: absolute;
            top: ${px(isMobile ? 192 : 246)}px;
            right: ${px(16)}px;
            width: ${px(72)}px;
            height: ${px(72)}px;
            display: none;
            border: 2px solid #ffc21c;
            border-radius: 16px;
            background: rgba(14,26,36,.94);
            color: #fff;
            font-size: ${px(31)}px;
            cursor: pointer;
            pointer-events: auto;
            z-index: 1600;
            box-shadow: 0 0 24px rgba(255,194,28,.45);
        `;
        killReward.textContent = '🪂📦';
        hud.appendChild(killReward);

        const killRewardPanel = document.createElement('div');
        killRewardPanel.id = 'killRewardPanel';
        killRewardPanel.style.cssText = `
            position: absolute;
            inset: 0;
            display: none;
            align-items: center;
            justify-content: center;
            background: rgba(3,8,13,.72);
            pointer-events: auto;
            z-index: 1700;
        `;
        killRewardPanel.innerHTML = `
            <div style="width:min(440px,88vw);padding:22px;border:2px solid #ffc21c;border-radius:18px;background:#101d27;box-shadow:0 18px 60px rgba(0,0,0,.55)">
                <div id="killRewardTitle" style="font-size:24px;font-weight:900;color:#ffc21c;margin-bottom:8px"></div>
                <div id="killRewardHint" style="font-size:14px;color:#d4e0e8;margin-bottom:16px">${this.t.killRewardHint}</div>
                <div id="killRewardOptions" style="display:grid;gap:10px"></div>
            </div>
        `;
        hud.appendChild(killRewardPanel);
        this.killRewardButton = killReward;
        this.killRewardPanel = killRewardPanel;
        killReward.addEventListener('click', () => {
            killRewardPanel.style.display = 'flex';
            document.exitPointerLock?.();
        });

        const topBar = document.createElement('div');
        topBar.style.cssText = `
            position: absolute;
            top: ${px(isMobile ? 14 : 16)}px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            flex-wrap: ${isMobile ? 'wrap' : 'nowrap'};
            justify-content: center;
            gap: ${px(12)}px;
            row-gap: ${px(8)}px;
            align-items: center;
            max-width: ${isMobile ? '96vw' : 'none'};
        `;
        hud.appendChild(topBar);

        const playersCount = document.createElement('div');
        playersCount.id = 'playersCount';
        playersCount.style.cssText = `
            background: rgba(14, 26, 36, 0.88);
            padding: ${px(8)}px ${px(18)}px;
            border-radius: ${px(10)}px;
            border: 2px solid rgba(255, 255, 255, 0.12);
            font-size: ${px(isMobile ? 14 : 18)}px;
            font-weight: 700;
            flex: ${isMobile ? '1 1 auto' : '0 0 auto'};
        `;
        playersCount.textContent = '\u0418\u0433\u0440\u043e\u043a\u043e\u0432: 32';
        topBar.appendChild(playersCount);

        const zoneInfo = document.createElement('div');
        zoneInfo.id = 'zoneInfo';
        zoneInfo.style.cssText = `
            background: rgba(14, 26, 36, 0.88);
            padding: ${px(8)}px ${px(16)}px;
            border-radius: ${px(10)}px;
            border: 2px solid rgba(255, 255, 255, 0.12);
            font-size: ${px(isMobile ? 12 : 14)}px;
            flex: ${isMobile ? '1 1 auto' : '0 0 auto'};
        `;
        zoneInfo.textContent = '\u0417\u043e\u043d\u0430: \u0411\u0435\u0437\u043e\u043f\u0430\u0441\u043d\u0430\u044f';
        topBar.appendChild(zoneInfo);

        const perkInfo = document.createElement('div');
        perkInfo.id = 'perkInfo';
        perkInfo.style.cssText = `
            background: rgba(255, 255, 255, 0.1);
            padding: ${px(6)}px ${px(12)}px;
            border-radius: ${px(10)}px;
            border: 2px solid rgba(255, 255, 255, 0.08);
            font-size: ${px(isMobile ? 11 : 12)}px;
            font-weight: 700;
            opacity: ${isMobile ? '0.88' : '1'};
        `;
        perkInfo.textContent = '\u041f\u0435\u0440\u043a: -';
        topBar.appendChild(perkInfo);

        const minimapWrap = document.createElement('div');
        minimapWrap.id = 'minimapWrap';
        minimapWrap.style.cssText = `
            position: absolute;
            top: ${px(isMobile ? 66 : 74)}px;
            right: ${px(14)}px;
            width: ${px(isMobile ? 120 : 156)}px;
            height: ${px(isMobile ? 120 : 156)}px;
            background: rgba(14, 26, 36, 0.86);
            border: 2px solid rgba(255, 255, 255, 0.14);
            border-radius: ${px(12)}px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.26);
            overflow: hidden;
            pointer-events: none;
            z-index: 1180;
        `;
        const minimapCanvas = document.createElement('canvas');
        minimapCanvas.id = 'minimapCanvas';
        minimapCanvas.width = isMobile ? 200 : 260;
        minimapCanvas.height = isMobile ? 200 : 260;
        minimapCanvas.style.cssText = `
            width: 100%;
            height: 100%;
            display: block;
        `;
        minimapWrap.appendChild(minimapCanvas);
        hud.appendChild(minimapWrap);
        this.minimapCanvas = minimapCanvas;
        this.minimapCtx = minimapCanvas.getContext('2d', { alpha: true });

        const leftPanel = document.createElement('div');
        leftPanel.style.cssText = `
            position: absolute;
            bottom: ${px(isMobile ? 240 : 120)}px;
            left: ${px(isMobile ? 30 : 14)}px;
            display: flex;
            flex-direction: column;
            gap: ${px(8)}px;
        `;
        hud.appendChild(leftPanel);

        const barWidth = px(260);
        const barHeight = px(26);

        const healthBar = document.createElement('div');
        healthBar.style.cssText = `
            width: ${barWidth}px;
            height: ${barHeight}px;
            background: rgba(14, 26, 36, 0.88);
            border-radius: ${px(8)}px;
            overflow: hidden;
            border: 2px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 6px 16px rgba(0,0,0,0.3);
        `;
        const healthFill = document.createElement('div');
        healthFill.id = 'healthFill';
        healthFill.style.cssText = `
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, #ff5252, #ff1744);
            transition: width 0.3s;
        `;
        healthBar.appendChild(healthFill);
        const healthText = document.createElement('div');
        healthText.id = 'healthText';
        healthText.style.cssText = `
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: ${px(16)}px;
            font-weight: 700;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.8);
            display: none;
        `;
        healthBar.appendChild(healthText);
        leftPanel.appendChild(healthBar);

        const armorBar = document.createElement('div');
        armorBar.style.cssText = `
            width: ${barWidth}px;
            height: ${barHeight}px;
            background: rgba(14, 26, 36, 0.88);
            border-radius: ${px(8)}px;
            overflow: hidden;
            border: 2px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 6px 16px rgba(0,0,0,0.3);
        `;
        const armorFill = document.createElement('div');
        armorFill.id = 'armorFill';
        armorFill.style.cssText = `
            width: 0%;
            height: 100%;
            background: linear-gradient(90deg, #42a5f5, #1976d2);
            transition: width 0.3s;
        `;
        armorBar.appendChild(armorFill);
        const armorText = document.createElement('div');
        armorText.id = 'armorText';
        armorText.style.cssText = `
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: ${px(16)}px;
            font-weight: 700;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.8);
            display: none;
        `;
        armorBar.appendChild(armorText);
        leftPanel.appendChild(armorBar);

        const inventory = document.createElement('div');
        inventory.id = 'inventory';
        inventory.style.cssText = `
            position: absolute;
            bottom: ${px(isMobile ? 12 : 8)}px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            gap: ${px(4)}px;
            background: rgba(14, 26, 36, 0.88);
            padding: ${px(8)}px ${px(10)}px;
            border-radius: ${px(10)}px;
            border: 2px solid rgba(255, 255, 255, 0.12);
            pointer-events: auto;
        `;
        hud.appendChild(inventory);

        const slotSize = px(isMobile ? 40 : 56);
        for (let i = 0; i < 10; i++) {
            const slot = document.createElement('div');
            slot.id = `slot${i}`;
            slot.style.cssText = `
                width: ${slotSize}px;
                height: ${slotSize}px;
                background: rgba(255, 255, 255, 0.1);
                border: 2px solid rgba(255, 255, 255, 0.25);
                border-radius: ${px(8)}px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: ${px(16)}px;
                font-weight: 700;
                position: relative;
                pointer-events: auto;
            `;
            slot.textContent = this.getSlotDisplayNumber(i);

            const slotNumber = document.createElement('div');
            slotNumber.style.cssText = `
                position: absolute;
                bottom: ${px(2)}px;
                right: ${px(4)}px;
                font-size: ${px(10)}px;
                color: rgba(255, 255, 255, 0.7);
            `;
            slotNumber.textContent = this.getSlotDisplayNumber(i);
            slot.appendChild(slotNumber);
            this._el['slotIcon' + i] = null;

            slot.addEventListener('click', () => {
                document.dispatchEvent(new CustomEvent('selectSlot', { detail: i }));
            });
            slot.addEventListener('touchstart', (e) => {
                e.preventDefault();
                document.dispatchEvent(new CustomEvent('selectSlot', { detail: i }));
            }, { passive: false });

            inventory.appendChild(slot);
        }

        const invulnerabilityTimer = document.createElement('div');
        invulnerabilityTimer.id = 'invulnerabilityTimer';
        invulnerabilityTimer.style.cssText = `
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: ${px(64)}px;
            font-weight: 800;
            color: #ffb300;
            text-shadow: 4px 4px 8px rgba(0,0,0,0.8);
            display: none;
        `;
        hud.appendChild(invulnerabilityTimer);

        const gameOverlay = document.getElementById('gameOverlay');

        const stormOverlay = document.createElement('div');
        stormOverlay.id = 'stormOverlay';
        stormOverlay.style.cssText = `
            position: absolute;
            inset: 0;
            background: radial-gradient(circle at 30% 30%, rgba(120, 140, 255, 0.2), rgba(20, 30, 40, 0.55));
            mix-blend-mode: screen;
            pointer-events: none;
            opacity: 0;
            transition: opacity 0.4s ease;
            z-index: 900;
        `;
        hud.appendChild(stormOverlay);

        const contamOverlay = document.createElement('div');
        contamOverlay.id = 'contamOverlay';
        contamOverlay.style.cssText = `
            position: absolute;
            inset: 0;
            background: radial-gradient(circle at 30% 30%, rgba(120, 255, 160, 0.18), rgba(12, 30, 18, 0.58));
            mix-blend-mode: screen;
            pointer-events: none;
            opacity: 0;
            transition: opacity 0.4s ease;
            z-index: 899;
        `;
        hud.appendChild(contamOverlay);

        const countdown = document.createElement('div');
        countdown.id = 'countdown';
        countdown.style.cssText = `
            position: absolute;
            top: ${px(90)}px;
            left: 50%;
            transform: translateX(-50%);
            font-size: ${px(42)}px;
            font-weight: 800;
            color: #ffb300;
            background: rgba(14, 26, 36, 0.9);
            padding: ${px(12)}px ${px(32)}px;
            border-radius: ${px(10)}px;
            border: 2px solid rgba(255, 255, 255, 0.12);
            text-shadow: 0 0 10px rgba(255,215,0,0.8);
            display: none;
        `;
        hud.appendChild(countdown);

        // FPS counter (top-right corner)
        const fpsEl = document.createElement('div');
        fpsEl.id = 'fpsDisplay';
        fpsEl.style.cssText = `
            position: absolute;
            top: ${px(4)}px;
            right: ${px(4)}px;
            font-size: ${px(14)}px;
            font-weight: 700;
            color: #0f0;
            background: rgba(0,0,0,0.6);
            padding: ${px(3)}px ${px(6)}px;
            border-radius: ${px(4)}px;
            z-index: 10001;
        `;
        hud.appendChild(fpsEl);

        const crosshair = document.createElement('div');
        crosshair.id = 'crosshair';
        crosshair.style.cssText = `
            position: absolute;
            left: 50%;
            top: 50%;
            width: ${px(18)}px;
            height: ${px(18)}px;
            transform: translate(-50%, -50%);
            pointer-events: none;
            z-index: 1100;
        `;
        const crossVert = document.createElement('div');
        crossVert.style.cssText = `
            position: absolute;
            left: 50%;
            top: 0;
            width: ${px(2)}px;
            height: 100%;
            transform: translateX(-50%);
            background: rgba(255, 255, 255, 0.9);
            box-shadow: 0 0 6px rgba(0, 0, 0, 0.6);
        `;
        const crossHorz = document.createElement('div');
        crossHorz.style.cssText = `
            position: absolute;
            top: 50%;
            left: 0;
            width: 100%;
            height: ${px(2)}px;
            transform: translateY(-50%);
            background: rgba(255, 255, 255, 0.9);
            box-shadow: 0 0 6px rgba(0, 0, 0, 0.6);
        `;
        crosshair.appendChild(crossVert);
        crosshair.appendChild(crossHorz);
        hud.appendChild(crosshair);

        const hitMarker = document.createElement('div');
        hitMarker.id = 'hitMarker';
        hitMarker.style.cssText = `
            position: absolute;
            left: 50%;
            top: 50%;
            width: ${px(30)}px;
            height: ${px(30)}px;
            transform: translate(-50%, -50%) rotate(45deg);
            border: ${px(3)}px solid rgba(255, 255, 255, 0.9);
            border-radius: ${px(4)}px;
            opacity: 0;
            transition: opacity 0.12s ease;
            pointer-events: none;
            z-index: 1101;
        `;
        hud.appendChild(hitMarker);

        const gameMessage = document.createElement('div');
        gameMessage.id = 'gameMessage';
        const messageTop = isMobile ? 18 : 30;
        const messageFont = isMobile ? Math.max(10, Math.round(px(30) / 3)) : px(30);
        gameMessage.style.cssText = `
            position: absolute;
            top: ${messageTop}%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: ${messageFont}px;
            font-weight: 800;
            color: #ffffff;
            text-shadow: 4px 4px 8px rgba(0,0,0,0.9);
            background: rgba(14, 26, 36, 0.9);
            padding: ${px(16)}px ${px(28)}px;
            border-radius: ${px(10)}px;
            border: 2px solid rgba(255, 255, 255, 0.12);
            display: none;
        `;
        hud.appendChild(gameMessage);

        const quickCommand = document.createElement('div');
        quickCommand.id = 'quickCommand';
        quickCommand.style.cssText = `
            position: absolute;
            top: ${px(18)}px;
            right: ${px(16)}px;
            background: rgba(14, 26, 36, 0.92);
            padding: ${px(8)}px ${px(14)}px;
            border-radius: ${px(10)}px;
            border: 2px solid rgba(255, 255, 255, 0.12);
            font-size: ${px(14)}px;
            font-weight: 800;
            display: none;
        `;
        hud.appendChild(quickCommand);

        const loreNote = document.createElement('div');
        loreNote.id = 'loreNote';
        loreNote.style.cssText = `
            position: absolute;
            bottom: ${px(180)}px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(14, 26, 36, 0.92);
            padding: ${px(10)}px ${px(18)}px;
            border-radius: ${px(12)}px;
            border: 2px solid rgba(255, 255, 255, 0.12);
            font-size: ${px(14)}px;
            font-weight: 700;
            max-width: min(520px, 88vw);
            text-align: center;
            display: none;
        `;
        hud.appendChild(loreNote);

        const pauseButton = document.createElement('div');
        pauseButton.id = 'pauseButton';
        pauseButton.textContent = 'II';
        pauseButton.style.cssText = `
            position: absolute;
            top: ${px(16)}px;
            left: ${px(16)}px;
            width: ${px(38)}px;
            height: ${px(38)}px;
            border-radius: ${px(10)}px;
            background: rgba(14, 26, 36, 0.88);
            border: 2px solid rgba(255, 255, 255, 0.12);
            font-size: ${px(16)}px;
            font-weight: 800;
            display: ${isMobile ? 'flex' : 'none'};
            align-items: center;
            justify-content: center;
            pointer-events: auto;
            cursor: pointer;
            z-index: 1300;
        `;
        pauseButton.addEventListener('click', () => {
            document.dispatchEvent(new CustomEvent('togglePause'));
        });
        pauseButton.addEventListener('touchstart', (e) => {
            e.preventDefault();
            e.stopPropagation();
            document.dispatchEvent(new CustomEvent('togglePause'));
        }, { passive: false });
        hud.appendChild(pauseButton);

        const pauseKeyInfo = document.createElement('div');
        pauseKeyInfo.id = 'pauseKeyInfo';
        pauseKeyInfo.textContent = this.t.pauseKeyInfo;
        pauseKeyInfo.style.cssText = `
            position: absolute;
            top: ${px(18)}px;
            left: ${px(64)}px;
            background: rgba(14, 26, 36, 0.88);
            padding: ${px(7)}px ${px(12)}px;
            border-radius: ${px(10)}px;
            border: 2px solid rgba(255, 255, 255, 0.12);
            font-size: ${px(12)}px;
            font-weight: 800;
            letter-spacing: 0.6px;
            display: ${isMobile ? 'none' : 'block'};
            z-index: 1300;
        `;
        hud.appendChild(pauseKeyInfo);

        const pauseOverlay = document.createElement('div');
        pauseOverlay.id = 'pauseOverlay';
        pauseOverlay.style.cssText = `
            position: absolute;
            inset: 0;
            display: none;
            align-items: center;
            justify-content: center;
            background: rgba(4, 8, 14, 0.72);
            z-index: 2000;
            pointer-events: auto;
        `;
                pauseOverlay.innerHTML = `
            <div id="pausePanel" style="
                min-width:${px(260)}px;
                max-width:min(420px, 88vw);
                background: rgba(12, 20, 30, 0.96);
                border: 2px solid rgba(255,255,255,0.12);
                border-radius:${px(12)}px;
                padding:${px(16)}px ${px(18)}px;
                color:#fff;
                font-weight:700;">
                <div id="pauseTitleText" style="font-size:${px(20)}px;margin-bottom:${px(10)}px;">${this.t.pauseTitle}</div>
                <div id="pauseControlsText" style="font-size:${px(12)}px;opacity:0.8;margin-bottom:${px(12)}px;">
                    ${this.t.pauseControls}
                </div>
                <div style="display:grid;gap:${px(8)}px;margin-bottom:${px(12)}px;">
                    <label style="display:grid;gap:${px(4)}px;font-size:${px(12)}px;">
                        <span id="pauseMusicLabel">${this.t.music}</span>
                        <input id="pauseMusicVolume" type="range" min="0" max="0.4" step="0.01" value="0.14">
                    </label>
                    <label style="display:grid;gap:${px(4)}px;font-size:${px(12)}px;">
                        <span id="pauseSfxLabel">${this.t.effects}</span>
                        <input id="pauseSfxVolume" type="range" min="0" max="1" step="0.01" value="0.48">
                    </label>
                    <label style="display:grid;gap:${px(4)}px;font-size:${px(12)}px;">
                        <span id="pauseSensLabel">${this.t.sensitivity}</span>
                        <input id="pauseSensitivity" type="range" min="0.5" max="2.4" step="0.05" value="1">
                    </label>
                </div>
                <div id="keybindSection" style="display:${isMobile ? 'none' : 'block'};margin-bottom:${px(10)}px;">
                    <div id="keybindsHintText" style="font-size:${px(12)}px;opacity:0.8;margin-bottom:${px(6)}px;">${this.t.keybindsHint}</div>
                    <div id="keybindList" style="display:grid;gap:${px(6)}px;"></div>
                </div>
                <div style="display:flex;gap:${px(8)}px;flex-wrap:wrap;">
                    <button id="pauseResume" class="perk-btn" style="flex:1;">${this.t.resume}</button>
                    <button id="pauseEdit" class="perk-btn" style="flex:1;display:${isMobile ? 'block' : 'none'};">${this.t.editButtons}</button>
                    <button id="pauseResetSettings" class="perk-btn" style="flex:1;">${this.t.resetSettings}</button>
                </div>
                <div id="pauseHint" style="margin-top:${px(10)}px;font-size:${px(11)}px;opacity:0.7;display:${isMobile ? 'block' : 'none'};">
                    ${this.t.pauseHint}
                </div>
            </div>
        `;
        hud.appendChild(pauseOverlay);

        const ammoInfo = document.createElement('div');
        ammoInfo.id = 'ammoInfo';
        ammoInfo.style.cssText = `
            position: absolute;
            bottom: ${px(isMobile ? 12 : 54)}px;
            left: ${isMobile ? 'max(16px, 4vw)' : `${px(16)}px`};
            background: rgba(14, 26, 36, 0.88);
            padding: ${px(8)}px ${px(14)}px;
            border-radius: ${px(8)}px;
            border: 2px solid rgba(255, 255, 255, 0.12);
            font-size: ${px(14)}px;
            font-weight: 700;
            text-shadow: 0 2px 4px rgba(0,0,0,0.6);
            z-index: 1200;
        `;
        ammoInfo.textContent = '';
        hud.appendChild(ammoInfo);

        const perkButton = document.createElement('div');
        perkButton.id = 'perkButton';
        perkButton.textContent = this.t.perkButton;
        perkButton.style.cssText = `
            position: absolute;
            bottom: ${px(isMobile ? 320 : 210)}px;
            left: ${px(16)}px;
            background: rgba(14, 26, 36, 0.88);
            padding: ${px(8)}px ${px(14)}px;
            border-radius: ${px(8)}px;
            border: 2px solid rgba(255, 255, 255, 0.12);
            font-size: ${px(12)}px;
            font-weight: 800;
            pointer-events: auto;
            cursor: pointer;
        `;
        perkButton.addEventListener('click', () => this.togglePerkPanel());
        perkButton.addEventListener('touchstart', (e) => {
            e.preventDefault();
            e.stopPropagation();
            this.togglePerkPanel();
        }, { passive: false });
        hud.appendChild(perkButton);

        const perkBackdrop = document.createElement('div');
        perkBackdrop.id = 'perkBackdrop';
        perkBackdrop.style.cssText = `
            position: absolute;
            inset: 0;
            display: none;
            align-items: center;
            justify-content: center;
            background: rgba(6, 12, 18, 0.68);
            backdrop-filter: blur(2px);
            z-index: 1480;
            pointer-events: none;
        `;
        perkBackdrop.addEventListener('click', (e) => {
            if (e.target !== perkBackdrop) return;
            if (this.perkPanelLocked) return;
            this.togglePerkPanel(false);
        });
        perkBackdrop.addEventListener('touchstart', (e) => {
            if (e.target !== perkBackdrop) return;
            if (this.perkPanelLocked) return;
            e.preventDefault();
            this.togglePerkPanel(false);
        }, { passive: false });
        root.appendChild(perkBackdrop);

        const perkPanel = document.createElement('div');
        perkPanel.id = 'perkPanel';
        perkPanel.setAttribute('data-allow-scroll', '1');
        perkPanel.style.cssText = `
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(14, 26, 36, 0.95);
            padding: ${px(16)}px ${px(18)}px;
            border-radius: ${px(12)}px;
            border: 2px solid rgba(255, 191, 0, 0.2);
            display: none;
            pointer-events: auto;
            min-width: min(${px(290)}px, 82vw);
            max-width: min(${px(340)}px, 86vw);
            max-height: ${isMobile ? '55vh' : '60vh'};
            overflow-y: auto;
            -webkit-overflow-scrolling: touch;
            overscroll-behavior: contain;
            touch-action: pan-y;
            z-index: 1500;
            box-shadow: 0 18px 40px rgba(0,0,0,0.42);
        `;
        perkBackdrop.appendChild(perkPanel);
        let perkTouchStartY = 0;
        let perkScrollStart = 0;
        let perkTouchMoved = false;

        // Build perk buttons ONCE — never overwrite innerHTML or handlers will be lost.
        const perkTitle = document.createElement('div');
        perkTitle.style.cssText = `font-size:${px(18)}px;font-weight:900;margin-bottom:${px(6)}px;color:#ffffff;text-shadow:0 2px 4px rgba(0,0,0,0.75);`;
        perkTitle.textContent = this.t.perkTitle;
        perkPanel.appendChild(perkTitle);

        const perkDesc = document.createElement('div');
        perkDesc.style.cssText = `font-size:${px(11)}px;color:#cbd7e1;line-height:1.35;margin-bottom:${px(10)}px;text-shadow:0 1px 3px rgba(0,0,0,0.7);`;
        perkDesc.textContent = this.t.perkDesc;
        perkPanel.appendChild(perkDesc);

        this.perkButtons = [];
        this.perkOptions.forEach(opt => {
            const btn = document.createElement('button');
            btn.className = 'perk-btn';
            btn.setAttribute('data-perk', opt.value);
            btn.textContent = opt.label;
            btn.style.cssText = `
                width: 100%;
                margin: ${px(4)}px 0;
                padding: ${px(8)}px ${px(10)}px;
                border-radius: ${px(8)}px;
                border: 1px solid rgba(255, 255, 255, 0.12);
                background: rgba(255, 255, 255, 0.08);
                color: #e9f0f6;
                font-weight: 700;
                cursor: pointer;
                font-size: ${px(14)}px;
            `;
            btn.addEventListener('click', (e) => {
                console.log('[perk] DEBUG: click event on button', e.target);
                e.stopPropagation();
                const perk = e.currentTarget.getAttribute('data-perk');
                console.log('[perk] Button clicked:', perk);
                if (!window.game?.isMobile?.()) window.game?.cameraController?.lock?.();
                document.dispatchEvent(new CustomEvent('selectPerk', { detail: perk }));
                this.togglePerkPanel(false);
            });
            perkPanel.appendChild(btn);
            this.perkButtons.push(btn);
        });

        perkPanel.addEventListener('touchstart', (e) => {
            const touch = e.touches?.[0];
            if (!touch) return;
            perkTouchStartY = touch.clientY;
            perkScrollStart = perkPanel.scrollTop;
            perkTouchMoved = false;
            perkPanel.dataset.touchScrollMoved = '0';
        }, { passive: true });
        perkPanel.addEventListener('touchmove', (e) => {
            const touch = e.touches?.[0];
            if (!touch) return;
            const deltaY = touch.clientY - perkTouchStartY;
            if (Math.abs(deltaY) > 8) {
                perkTouchMoved = true;
                perkPanel.dataset.touchScrollMoved = '1';
            }
            if (perkPanel.scrollHeight > perkPanel.clientHeight + 2) {
                perkPanel.scrollTop = perkScrollStart - deltaY;
                e.stopPropagation();
                e.preventDefault();
            }
        }, { passive: false });
        perkPanel.addEventListener('touchend', () => {
            requestAnimationFrame(() => {
                perkPanel.dataset.touchScrollMoved = perkTouchMoved ? '1' : '0';
            });
        }, { passive: true });
        perkPanel.addEventListener('wheel', (e) => {
            e.stopPropagation();
        }, { passive: true });
        if (isMobile) {
            // Mobile: add navigation buttons after the already-created perk buttons
            const navRow = document.createElement('div');
            navRow.style.cssText = `display:grid;grid-template-columns:1fr 1fr;gap:${px(8)}px;margin-top:${px(8)}px;margin-bottom:${px(8)}px;`;
            const perkPrev = document.createElement('div');
            perkPrev.id = 'perkPrev';
            perkPrev.className = 'perk-btn';
            perkPrev.textContent = this.t.perkPrev;
            perkPrev.style.cssText = `
                width: 100%; margin: 0; padding: ${px(10)}px;
                border-radius: ${px(8)}px; border: 1px solid rgba(255, 255, 255, 0.12);
                background: rgba(255, 255, 255, 0.08); color: #e9f0f6;
                font-weight: 700; cursor: pointer; text-align: center;
                pointer-events: auto; user-select: none; touch-action: manipulation;
                display: flex; align-items: center; justify-content: center;
            `;
            const perkNext = document.createElement('div');
            perkNext.id = 'perkNext';
            perkNext.className = 'perk-btn';
            perkNext.textContent = this.t.perkNext;
            perkNext.style.cssText = `
                width: 100%; margin: 0; padding: ${px(10)}px;
                border-radius: ${px(8)}px; border: 1px solid rgba(255, 255, 255, 0.12);
                background: rgba(255, 255, 255, 0.08); color: #e9f0f6;
                font-weight: 700; cursor: pointer; text-align: center;
                pointer-events: auto; user-select: none; touch-action: manipulation;
                display: flex; align-items: center; justify-content: center;
            `;
            const perkSelectMobile = document.createElement('div');
            perkSelectMobile.id = 'perkSelectMobile';
            perkSelectMobile.className = 'perk-btn';
            perkSelectMobile.textContent = this.t.perkSelect;
            perkSelectMobile.style.cssText = `
                width: 100%; margin: 0; padding: ${px(10)}px;
                border-radius: ${px(8)}px; border: 1px solid rgba(255, 255, 255, 0.12);
                background: rgba(255, 255, 255, 0.08); color: #e9f0f6;
                font-weight: 700; cursor: pointer; text-align: center;
                pointer-events: auto; user-select: none; touch-action: manipulation;
                display: flex; align-items: center; justify-content: center;
            `;
            navRow.appendChild(perkPrev);
            navRow.appendChild(perkNext);
            perkPanel.appendChild(navRow);
            perkPanel.appendChild(perkSelectMobile);
            this.perkButtons = [];
            const mobileButtons = Array.from(perkPanel.querySelectorAll('.perk-btn'));
            mobileButtons.forEach(btn => {
                btn.style.cssText = `
                    width: 100%;
                    margin: 0;
                    padding: ${px(10)}px ${px(10)}px;
                    border-radius: ${px(8)}px;
                    border: 1px solid rgba(255, 255, 255, 0.12);
                    background: rgba(255, 255, 255, 0.08);
                    color: #e9f0f6;
                    font-weight: 700;
                    cursor: pointer;
                    pointer-events: auto;
                    user-select: none;
                    -webkit-user-select: none;
                    touch-action: manipulation;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                `;
            });
            const bindTap = (el, fn) => {
                if (!el) return;
                let pressed = false;
                el.addEventListener('touchstart', (e) => {
                    pressed = true;
                    perkPanel.dataset.touchScrollMoved = '0';
                    e.preventDefault();
                    e.stopPropagation();
                }, { passive: false });
                el.addEventListener('touchend', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    if (!pressed) return;
                    pressed = false;
                    fn();
                }, { passive: false });
                el.addEventListener('pointerup', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    fn();
                });
                el.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    fn();
                });
            };
            bindTap(perkPanel.querySelector('#perkPrev'), () => {
                this.setPerkMenuSelection((this.perkMenuIndex ?? 0) - 1);
            });
            bindTap(perkPanel.querySelector('#perkNext'), () => {
                this.setPerkMenuSelection((this.perkMenuIndex ?? 0) + 1);
            });
            bindTap(perkPanel.querySelector('#perkSelectMobile'), () => {
                const perk = this.getPerkMenuValue();
                if (!perk) return;
                document.dispatchEvent(new CustomEvent('selectPerk', { detail: perk }));
                this.togglePerkPanel(false);
            });
            perkPanel.addEventListener('touchmove', (e) => {
                const t = e.touches?.[0];
                if (!t || !perkPanel.dataset.swipeStartX) return;
                const dx = t.clientX - Number(perkPanel.dataset.swipeStartX);
                if (Math.abs(dx) > 56) {
                    if (dx > 0) this.setPerkMenuSelection((this.perkMenuIndex ?? 0) - 1);
                    else this.setPerkMenuSelection((this.perkMenuIndex ?? 0) + 1);
                    perkPanel.dataset.swipeStartX = String(t.clientX);
                }
            }, { passive: true });
            perkPanel.addEventListener('touchstart', (e) => {
                const t = e.touches?.[0];
                if (!t) return;
                perkPanel.dataset.swipeStartX = String(t.clientX);
            }, { passive: true });
        }

        // Style desktop perk buttons (only on first build)
        if (!this._perkButtonsBuilt) {
            this._perkButtonsBuilt = true;
            this.perkButtons.forEach(btn => {
                btn.style.cssText = `
                    width: 100%;
                    margin: ${px(4)}px 0;
                    padding: ${px(8)}px ${px(10)}px;
                    border-radius: ${px(8)}px;
                    border: 1px solid rgba(255, 255, 255, 0.12);
                    background: rgba(255, 255, 255, 0.08);
                    color: #e9f0f6;
                    font-weight: 700;
                    cursor: pointer;
                `;
            });
        }
        // perkPanel already appended to hud above — do NOT nest inside perkBackdrop

        const scoreboard = document.createElement('div');
        scoreboard.id = 'scoreboard';
        scoreboard.style.cssText = `
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            min-width: min(520px, 88vw);
            background: rgba(14, 26, 36, 0.95);
            padding: ${px(18)}px ${px(22)}px;
            border-radius: ${px(14)}px;
            border: 2px solid rgba(255, 255, 255, 0.15);
            box-shadow: 0 12px 30px rgba(0,0,0,0.35);
            display: none;
            text-align: center;
            z-index: 1200;
        `;
        scoreboard.innerHTML = `
            <div id="scoreboardTitle" style="font-size:${px(22)}px;font-weight:800;margin-bottom:${px(8)}px;">${this.t.scoreboardTitle}</div>
            <div id="scoreboardBody" style="display:grid;gap:${px(6)}px;font-size:${px(14)}px;"></div>
        `;
        hud.appendChild(scoreboard);

        const style = document.createElement('style');
        style.textContent = `
            @keyframes pulse {
                0%, 100% { transform: translate(-50%, -50%) scale(1); }
                50% { transform: translate(-50%, -50%) scale(1.1); }
            }
        `;
        document.head.appendChild(style);

        // Cache DOM elements for hot-path access (avoids getElementById in update loop)
        this._el.visionOverlay = visionOverlay;
        this._el.lootFeed = lootFeed;
        this._el.killReward = killReward;
        this._el.killRewardPanel = killRewardPanel;
        this._el.playersCount = playersCount;
        this._el.zoneInfo = zoneInfo;
        this._el.perkInfo = perkInfo;
        this._el.healthFill = healthFill;
        this._el.healthText = healthText;
        this._el.armorFill = armorFill;
        this._el.armorText = armorText;
        this._el.crosshair = crosshair;
        this._el.hitMarker = hitMarker;
        this._el.gameMessage = gameMessage;
        this._el.quickCommand = quickCommand;
        this._el.loreNote = loreNote;
        this._el.invulnerabilityTimer = invulnerabilityTimer;
        this._el.gameOverlay = gameOverlay;
        this._el.gameOverStats = document.getElementById('gameOverStats');
        this._el.stormOverlay = stormOverlay;
        this._el.contamOverlay = contamOverlay;
        this._el.countdown = countdown;
        this._el.fpsDisplay = fpsEl;
        for (let si = 0; si < 10; si++) this._el['slot' + si] = document.getElementById('slot' + si);
        this._el.perkButton = document.getElementById('perkButton');
        this._el.perkPanel = document.getElementById('perkPanel');
        this._el.perkBackdrop = document.getElementById('perkBackdrop');
        this._el.scoreboard = document.getElementById('scoreboard');
        this._el.scoreboardBody = document.getElementById('scoreboardBody');
        this._el.pauseOverlay = document.getElementById('pauseOverlay');
        this._el.pauseResume = document.getElementById('pauseResume');
        this._el.pauseEdit = document.getElementById('pauseEdit');
        this._el.pauseResetSettings = document.getElementById('pauseResetSettings');
        this._el.pauseMusicVolume = document.getElementById('pauseMusicVolume');
        this._el.pauseSfxVolume = document.getElementById('pauseSfxVolume');
        this._el.pauseSensitivity = document.getElementById('pauseSensitivity');
        this._el.pauseHint = document.getElementById('pauseHint');
        this._el.keybindList = document.getElementById('keybindList');
        this._el.ammoInfo = document.getElementById('ammoInfo');
        this._el.gameOverTitle = document.getElementById('gameOverTitle');
        this._el.gameOverMessage = document.getElementById('gameOverMessage');
        this._el.perkMobileTitle = document.getElementById('perkMobileTitle');
        this._el.perkMobileDesc = document.getElementById('perkMobileDesc');
        this._el.perkMobileIndex = document.getElementById('perkMobileIndex');
        this._el.perkPrev = document.getElementById('perkPrev');
        this._el.perkNext = document.getElementById('perkNext');
        this._el.perkSelectMobile = document.getElementById('perkSelectMobile');
        this._el.touchStick = document.getElementById('touchStick');
        this._el.touchArea = document.getElementById('touchArea');
        this._el.touchKnob = document.getElementById('touchKnob');
        this._el.touchJump = document.getElementById('touchJump');
        this._el.touchAttack = document.getElementById('touchAttack');
        this._el.touchInteract = document.getElementById('touchInteract');
        this.bindPauseUI();
        this.bindSettingsUI();
        this.initKeybindUI();
        if (isMobile) {
            this.initTouchLayout();
        }
    }

    show() {
        if (this.root) this.root.style.display = 'block';
        // Show touch controls only on mobile
        if (this._isMobile) {
            const stick = this._el.touchStick;
            const area = this._el.touchArea;
            if (stick) stick.style.display = 'block';
            if (area) area.style.display = 'block';
        }
    }

    hide() {
        if (this.root) this.root.style.display = 'none';
        // Hide touch controls
        const stick = this._el.touchStick;
        const area = this._el.touchArea;
        if (stick) stick.style.display = 'none';
        if (area) area.style.display = 'none';
    }

    updateJoystick(joystick) {
        if (!joystick || !this._isMobile) return;
        const stick = this._el.touchStick;
        const knob = this._el.touchKnob;
        if (!stick || !knob) return;
        if (joystick.active) {
            stick.style.display = 'block';
            stick.style.left = `${joystick.baseX}px`;
            stick.style.top = `${joystick.baseY}px`;
            stick.style.opacity = '0.7';
            const dx = joystick.currentX - joystick.baseX;
            const dy = joystick.currentY - joystick.baseY;
            knob.style.transform = `translate(${dx}px, ${dy}px)`;
        } else {
            stick.style.display = 'none';
            stick.style.opacity = '0';
            knob.style.transform = 'translate(0px, 0px)';
        }
    }

    bindPauseUI() {
        const resume = this._el.pauseResume;
        const edit = this._el.pauseEdit;
        const reset = this._el.pauseResetSettings;
        if (resume) {
            resume.addEventListener('click', () => {
                document.dispatchEvent(new CustomEvent('togglePause'));
            });
            resume.addEventListener('touchstart', (e) => {
                e.preventDefault();
                e.stopPropagation();
                document.dispatchEvent(new CustomEvent('togglePause'));
            }, { passive: false });
        }
        if (edit) {
            edit.addEventListener('click', () => this.toggleEditControls());
            edit.addEventListener('touchstart', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.toggleEditControls();
            }, { passive: false });
        }
        if (reset) {
            const run = (e) => {
                e.preventDefault();
                e.stopPropagation();
                document.dispatchEvent(new CustomEvent('resetSettings'));
            };
            reset.addEventListener('click', run);
            reset.addEventListener('touchstart', run, { passive: false });
        }
    }

    bindSettingsUI() {
        const music = this._el.pauseMusicVolume;
        const sfx = this._el.pauseSfxVolume;
        const sensitivity = this._el.pauseSensitivity;
        const emitAudio = () => {
            document.dispatchEvent(new CustomEvent('setAudioSettings', {
                detail: {
                    musicVolume: Number(music?.value || 0.14),
                    sfxVolume: Number(sfx?.value || 0.48)
                }
            }));
        };
        if (music) {
            music.addEventListener('input', emitAudio);
            music.addEventListener('change', emitAudio);
        }
        if (sfx) {
            sfx.addEventListener('input', emitAudio);
            sfx.addEventListener('change', emitAudio);
        }
        if (sensitivity) {
            const emitSensitivity = () => {
                document.dispatchEvent(new CustomEvent('setLookSensitivity', { detail: Number(sensitivity.value || 1) }));
            };
            sensitivity.addEventListener('input', emitSensitivity);
            sensitivity.addEventListener('change', emitSensitivity);
        }
    }

    showPause(show) {
        const overlay = this._el.pauseOverlay;
        if (!overlay) return;
        overlay.style.display = show ? 'flex' : 'none';
        if (!show) this.toggleEditControls(false);
    }

    toggleEditControls(force = null) {
        const root = document.documentElement;
        const enabled = force !== null ? force : !root.classList.contains('edit-controls');
        if (enabled) root.classList.add('edit-controls');
        else root.classList.remove('edit-controls');
        const hint = this._el.pauseHint;
        if (hint) hint.style.display = enabled ? 'block' : 'none';
    }

    initTouchLayout() {
        const ids = ['touchJump', 'touchAttack', 'touchInteract'];
        const saved = localStorage.getItem('mazearena_touch_layout');
        if (saved) {
            try {
                const data = JSON.parse(saved);
                ids.forEach((id) => {
                    const el = this._el[id] || document.getElementById(id);
                    if (!el || !data[id]) return;
                    el.style.left = `${data[id].x}px`;
                    el.style.top = `${data[id].y}px`;
                });
            } catch (_) {}
        }

        let active = null;
        let offset = { x: 0, y: 0 };
        const saveLayout = () => {
            const data = {};
            ids.forEach((id) => {
                const el = this._el[id] || document.getElementById(id);
                if (!el) return;
                const rect = el.getBoundingClientRect();
                data[id] = { x: rect.left, y: rect.top };
            });
            localStorage.setItem('mazearena_touch_layout', JSON.stringify(data));
        };

        const onDown = (e) => {
            if (!document.documentElement.classList.contains('edit-controls')) return;
            const target = e.target.closest ? e.target.closest('.touch-btn') : null;
            if (!target) return;
            active = target;
            const rect = active.getBoundingClientRect();
            const clientX = e.touches ? e.touches[0].clientX : e.clientX;
            const clientY = e.touches ? e.touches[0].clientY : e.clientY;
            offset.x = clientX - rect.left;
            offset.y = clientY - rect.top;
            e.preventDefault();
        };

        const onMove = (e) => {
            if (!active) return;
            const clientX = e.touches ? e.touches[0].clientX : e.clientX;
            const clientY = e.touches ? e.touches[0].clientY : e.clientY;
            active.style.left = `${clientX - offset.x}px`;
            active.style.top = `${clientY - offset.y}px`;
            active.style.right = 'auto';
            active.style.bottom = 'auto';
            e.preventDefault();
        };

        const onUp = () => {
            if (!active) return;
            active = null;
            saveLayout();
        };

        document.addEventListener('touchstart', onDown, { passive: false });
        document.addEventListener('touchmove', onMove, { passive: false });
        document.addEventListener('touchend', onUp);
        document.addEventListener('mousedown', onDown);
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
    }

    initKeybindUI() {
        const list = this._el.keybindList;
        if (!list) return;
        this.keybindActions = Object.keys(this.t.keybinds).map((id) => ({ id, label: this.t.keybinds[id] }));
        this.renderKeybinds();
        this.bindRebindListeners();
    }

    renderKeybinds() {
        const list = this._el.keybindList;
        if (!list || !this.keybindActions) return;
        list.innerHTML = '';
        const binds = this.getStoredKeybinds();
        this.keybindActions.forEach((item) => {
            const row = document.createElement('div');
            row.style.cssText = `
                display:flex;
                align-items:center;
                justify-content:space-between;
                gap:${Math.max(6, Math.round(list.clientWidth * 0.02))}px;
                background: rgba(255,255,255,0.06);
                border: 1px solid rgba(255,255,255,0.12);
                border-radius: 8px;
                padding: 6px 8px;
                font-size: 12px;
            `;
            const left = document.createElement('div');
            left.textContent = item.label;
            const btn = document.createElement('button');
            btn.className = 'perk-btn';
            btn.dataset.action = item.id;
            btn.textContent = this.formatKeyLabel(binds[item.id] || item.id);
            btn.style.cssText = `
                padding: 4px 8px;
                font-size: 11px;
                border-radius: 8px;
                min-width: 70px;
            `;
            btn.addEventListener('click', () => this.beginRebind(item.id, btn));
            row.appendChild(left);
            row.appendChild(btn);
            list.appendChild(row);
        });
    }

    getStoredKeybinds() {
        try {
            const raw = localStorage.getItem('mazearena_keybinds');
            return raw ? JSON.parse(raw) : {};
        } catch (_) {
            return {};
        }
    }

    formatKeyLabel(code) {
        if (code === 'MouseLeft') return 'LMB';
        if (code === 'MouseRight') return 'RMB';
        if (code === 'Space') return 'SPACE';
        if (code.startsWith('Key')) return code.replace('Key', '');
        if (code.startsWith('Digit')) return code.replace('Digit', '');
        return code;
    }

    bindRebindListeners() {
        document.addEventListener('keydown', (e) => {
            if (!this.rebindAction) return;
            e.preventDefault();
            this.finishRebind(this.rebindAction, e.code);
        });
        document.addEventListener('mousedown', (e) => {
            if (!this.rebindAction) return;
            e.preventDefault();
            const code = e.button === 0 ? 'MouseLeft' : e.button === 2 ? 'MouseRight' : `Mouse${e.button}`;
            this.finishRebind(this.rebindAction, code);
        });
    }

    beginRebind(action, button) {
        this.rebindAction = action;
        if (button) button.textContent = '...';
        this.rebindButton = button || null;
    }

    finishRebind(action, code) {
        this.rebindAction = null;
        if (this.rebindButton) {
            this.rebindButton.textContent = this.formatKeyLabel(code);
            this.rebindButton = null;
        }
        try {
            const binds = this.getStoredKeybinds();
            for (const key in binds) {
                if (binds[key] === code && key !== action) {
                    delete binds[key];
                }
            }
            binds[action] = code;
            localStorage.setItem('mazearena_keybinds', JSON.stringify(binds));
        } catch (_) {}
        document.dispatchEvent(new CustomEvent('rebindKey', { detail: { action, code } }));
        this.renderKeybinds();
    }

    updateHealth(health, maxHealth) {
        const healthFill = this._el.healthFill;
        if (!healthFill) return;
        const percent = (health / maxHealth) * 100;
        if (this._lastState.healthPercent === percent) return;
        this._lastState.healthPercent = percent;
        healthFill.style.width = `${percent}%`;
    }

    updateArmor(armor, maxArmor) {
        const armorFill = this._el.armorFill;
        if (!armorFill) return;
        const percent = (armor / maxArmor) * 100;
        if (this._lastState.armorPercent === percent) return;
        this._lastState.armorPercent = percent;
        armorFill.style.width = `${percent}%`;
    }

    updatePlayersCount(count) {
        const playersCount = this._el.playersCount;
        if (this._lastState.playersCount === count) return;
        this._lastState.playersCount = count;
        playersCount.textContent = `\u0418\u0433\u0440\u043e\u043a\u043e\u0432: ${count}`;
    }

    updateZoneInfo(text, isDangerous = false) {
        const zoneInfo = this._el.zoneInfo;
        zoneInfo.textContent = `\u0417\u043e\u043d\u0430: ${text}`;
        zoneInfo.style.background = isDangerous
            ? 'rgba(255, 82, 82, 0.85)'
            : 'rgba(14, 26, 36, 0.88)';
    }

    setRoundMode(label) {
        return label;
    }

    setPerk(label) {
        const perkInfo = this._el.perkInfo;
        if (perkInfo) perkInfo.textContent = this.t.perkLabel(label);
        const perkButton = this._el.perkButton;
        if (perkButton) {
            if (label && label !== '-') {
                perkButton.style.display = 'none';
            } else {
                perkButton.style.display = 'block';
                perkButton.textContent = this.t.perkButton;
            }
        }
    }

    setSettingsValues(settings = {}) {
        const music = this._el.pauseMusicVolume;
        const sfx = this._el.pauseSfxVolume;
        const sensitivity = this._el.pauseSensitivity;
        if (music && settings.musicVolume !== undefined) music.value = String(settings.musicVolume);
        if (sfx && settings.sfxVolume !== undefined) sfx.value = String(settings.sfxVolume);
        if (sensitivity && settings.lookSensitivity !== undefined) sensitivity.value = String(settings.lookSensitivity);
    }

    updateInventory(items, selectedSlot) {
        for (let i = 0; i < 10; i++) {
            const slot = this._el['slot' + i];
            if (!slot) continue;
            const item = items[i];
            const type = item ? ((typeof item === 'string') ? item : (item?.type || '')) : null;
            const prevType = this._lastState.slotTypes[i];
            // Skip slot if type and selected state unchanged
            if (prevType === type && this._lastState.selectedSlot === selectedSlot) {
                if (i === selectedSlot) {
               slot.style.border = '3px solid #ffb300';
               slot.style.boxShadow = '0 0 10px rgba(255, 179, 0, 0.5)';
           } else {
                slot.style.border = '2px solid rgba(255, 255, 255, 0.8)';
               slot.style.boxShadow = 'none';
           }
           continue;
            }
            if (item) {
                this._lastState.slotTypes[i] = type;
                slot.style.background = 'rgba(255, 255, 255, 0.2)';
                slot.style.border = '2px solid rgba(255, 255, 255, 0.8)';
                let icon = this._el['slotIcon' + i];
                if (!icon) {
                    icon = document.createElement('div');
                    icon.className = 'weapon-icon';
                    icon.style.cssText = 'font-size: 12px; font-weight: 800; color: #ffffff;';
                    slot.appendChild(icon);
                    this._el['slotIcon' + i] = icon;
                }
                const label = HUD.ICON_MAP[type] || type;
                icon.textContent = label || ``;
                icon.style.display = `block`;
            } else {
                slot.style.background = 'rgba(255, 255, 255, 0.1)';
                slot.style.border = '2px solid rgba(255, 255, 255, 0.25)';
                const oldIcon = this._el['slotIcon' + i];
                if (oldIcon) {
                    oldIcon.remove();
                    this._el['slotIcon' + i] = null;
                    this._lastState.slotTypes[i] = null;
                }
            }
            if (i === selectedSlot) {
                slot.style.border = '3px solid #ffb300';
                slot.style.boxShadow = '0 0 10px rgba(255, 179, 0, 0.5)';
            } else {
                slot.style.boxShadow = 'none';
            }
        }
        this._lastState.selectedSlot = selectedSlot;
    }

    showInvulnerabilityTimer(seconds) {
        const timer = this._el.invulnerabilityTimer;
        timer.textContent = seconds > 0 ? Math.ceil(seconds) : '';
        timer.style.display = seconds > 0 ? 'block' : 'none';
    }

    showGameOver(message, stats) {
        const overlay = this._el.gameOverlay;
        const title = this._el.gameOverTitle;
        const msg = this._el.gameOverMessage;
        const statsEl = this._el.gameOverStats;
        if (title) title.textContent = this.t.gameOverTitle;
        if (msg) msg.textContent = message || '';
        if (statsEl) {
            if (stats) {
                const lines = [];
                lines.push(this.t.gameOverPlace(stats.place, stats.kills));
                if (stats.record && stats.record.best) {
                    lines.push(this.t.gameOverRecord(stats.record.best.place, stats.record.best.kills));
                    if (stats.record.newRecord && (stats.record.newRecord.place || stats.record.newRecord.kills)) {
                        lines.push(this.t.newRecord);
                    }
                }
                statsEl.textContent = lines.join(' · ');
            } else {
                statsEl.textContent = '';
            }
        }
        overlay.style.display = 'flex';
        overlay.style.pointerEvents = 'auto';
    }

    hideGameOver() {
        const overlay = this._el.gameOverlay;
        overlay.style.display = 'none';
    }

    showCountdown(seconds) {
        const countdown = this._el.countdown;
        countdown.textContent = seconds;
        countdown.style.display = 'block';
    }

    hideCountdown() {
        const countdown = this._el.countdown;
        countdown.style.display = 'none';
    }

    updateFpsDisplay(fps) {
        const fpsEl = this._el.fpsDisplay;
        if (fpsEl) {
            fpsEl.textContent = `${fps} FPS`;
            if (fps >= 50) fpsEl.style.color = '#0f0';
            else if (fps >= 30) fpsEl.style.color = '#ff0';
            else fpsEl.style.color = '#f00';
        }
    }

    showGameMessage(message) {
        const gameMessage = this._el.gameMessage;
        gameMessage.textContent = message;
        gameMessage.style.display = 'block';
        gameMessage.style.animation = 'pulse 1.5s infinite';

        setTimeout(() => {
            gameMessage.style.display = 'none';
            gameMessage.style.animation = 'none';
        }, 3000);
    }

    showQuickCommand(message) {
        const quick = this._el.quickCommand;
        if (!quick) return;
        quick.textContent = message;
        quick.style.display = 'block';
        clearTimeout(this.quickTimer);
        this.quickTimer = setTimeout(() => {
            quick.style.display = 'none';
        }, 1600);
    }

    showLoreNote(text) {
        const note = this._el.loreNote;
        if (!note) return;
        note.textContent = text;
        note.style.display = 'block';
        clearTimeout(this.noteTimer);
        this.noteTimer = setTimeout(() => {
            note.style.display = 'none';
        }, 3200);
    }

    showLootNotification(text) {
        const feed = this._el.lootFeed;
        if (!feed || !text) return;

        const item = document.createElement('div');
        item.style.cssText = `
            background: rgba(14, 26, 36, 0.92);
            border: 2px solid rgba(255, 191, 0, 0.24);
            border-radius: 10px;
            padding: 10px 12px;
            color: #f7fbff;
            font-size: 13px;
            font-weight: 700;
            box-shadow: 0 8px 20px rgba(0,0,0,0.28);
            transform: translateX(16px);
            opacity: 0;
            transition: transform 0.2s ease, opacity 0.2s ease;
        `;
        item.textContent = text;
        feed.appendChild(item);

        requestAnimationFrame(() => {
            item.style.transform = 'translateX(0)';
            item.style.opacity = '1';
        });

        setTimeout(() => {
            item.style.transform = 'translateX(18px)';
            item.style.opacity = '0';
            setTimeout(() => item.remove(), 220);
        }, 2400);
    }

    showKillReward(kills, options, onSelect) {
        if (!this.killRewardButton || !this.killRewardPanel || !options?.length) return;
        this.killRewardButton.style.display = 'block';
        this.killRewardButton.title = this.t.killRewardButton(kills);
        const title = this.killRewardPanel.querySelector('#killRewardTitle');
        const list = this.killRewardPanel.querySelector('#killRewardOptions');
        title.textContent = this.t.killRewardTitle(kills);
        list.replaceChildren();
        for (const option of options) {
            const button = document.createElement('button');
            button.type = 'button';
            button.textContent = option.label;
            button.style.cssText = 'padding:13px 16px;border:1px solid rgba(255,255,255,.16);border-radius:10px;background:#22323e;color:#fff;font:700 15px Trebuchet MS;cursor:pointer';
            button.addEventListener('click', () => {
                this.killRewardPanel.style.display = 'none';
                this.killRewardButton.style.display = 'none';
                onSelect?.(option.id);
                // Pointer lock handled by setPaused(false) in main.js — don't double-request
            });
            list.appendChild(button);
        }
        this.killRewardPanel.style.display = 'flex';
        document.exitPointerLock?.();
    }

    showHitMarker() {
        const hit = this._el.hitMarker;
        if (!hit) return;
        hit.style.opacity = '1';
        clearTimeout(this.hitTimer);
        this.hitTimer = setTimeout(() => {
            hit.style.opacity = '0';
        }, 120);
    }

    setStormActive(active, type = 'storm') {
        const storm = this._el.stormOverlay;
        if (!storm) return;
        if (type === 'radiation') {
            storm.style.background = 'radial-gradient(circle at 30% 30%, rgba(120, 255, 160, 0.18), rgba(12, 30, 18, 0.58))';
        } else {
            storm.style.background = 'radial-gradient(circle at 30% 30%, rgba(120, 140, 255, 0.2), rgba(20, 30, 40, 0.55))';
        }
        storm.style.opacity = active ? '1' : '0';
    }

    setContamActive(active) {
        const contam = this._el.contamOverlay;
        if (!contam) return;
        contam.style.opacity = active ? '1' : '0';
    }

    setVisionIntensity(intensity = 0) {
        const overlay = this._el.visionOverlay;
        if (!overlay) return;
        overlay.style.opacity = `${Math.max(0, Math.min(0.85, intensity))}`;
    }

    showScoreboard(lines = []) {
        const board = this._el.scoreboard;
        const body = this._el.scoreboardBody;
        if (!board || !body) return;
        body.innerHTML = lines.map(line => `<div>${line}</div>`).join('');
        board.style.display = 'block';
    }

    hideScoreboard() {
        const board = this._el.scoreboard;
        if (board) {
            board.style.display = 'none';
        }
    }

    setPerkSelectionEnabled(enabled) {
        const perkButton = this._el.perkButton;
        const perkPanel = this._el.perkPanel;
        const perkBackdrop = this._el.perkBackdrop;
        if (perkButton) {
            perkButton.style.display = enabled ? 'block' : 'none';
        }
        if (!enabled && perkPanel) {
            perkPanel.style.display = 'none';
        }
        if (!enabled && perkBackdrop) {
            perkBackdrop.style.display = 'none';
        }
    }

    setPerkPanelLock(locked) {
        this.perkPanelLocked = !!locked;
        const perkButton = this._el.perkButton;
        if (perkButton) {
            perkButton.style.opacity = this.perkPanelLocked ? '0.95' : '1';
        }
    }

    togglePerkPanel(force) {
        const panel = this._el.perkPanel;
        const backdrop = this._el.perkBackdrop;
        if (!panel || !backdrop) return;
        const currentlyOpen = panel.style.display === 'block';
        if (this.perkPanelLocked && force !== true && force !== false && currentlyOpen) return;
        if (typeof force === 'boolean') {
            panel.style.display = force ? 'block' : 'none';
            backdrop.style.display = force ? 'flex' : 'none';
            backdrop.style.pointerEvents = 'none';
            if (force) {
                this.setPerkMenuSelection(this.getPerkMenuSelection());
            }
            return;
        }
        panel.style.display = panel.style.display === 'block' ? 'none' : 'block';
        backdrop.style.display = panel.style.display === 'block' ? 'flex' : 'none';
        backdrop.style.pointerEvents = 'none';
        if (panel.style.display === 'block') {
            this.setPerkMenuSelection(this.getPerkMenuSelection());
        }
    }

    setPerkMenuSelection(index) {
        const count = this.perkButtons?.length ? this.perkButtons.length : this.perkOptions.length;
        if (!count) return;
        const safeIndex = ((index % count) + count) % count;
        if (!this.perkButtons || !this.perkButtons.length) {
            this.perkMenuIndex = safeIndex;
            const title = this._el.perkMobileTitle;
            const desc = this._el.perkMobileDesc;
            const idx = this._el.perkMobileIndex;
            const option = this.perkOptions[safeIndex];
            if (title) title.textContent = option?.label || '';
            if (desc) desc.textContent = option?.desc || '';
            if (idx) idx.textContent = `${safeIndex + 1}/${this.perkOptions.length}`;
            return;
        }
        this.perkButtons.forEach((btn, i) => {
            if (i === safeIndex) {
                btn.style.background = 'rgba(255, 179, 0, 0.3)';
                btn.style.border = '1px solid rgba(255, 179, 0, 0.8)';
            } else {
                btn.style.background = 'rgba(255, 255, 255, 0.08)';
                btn.style.border = '1px solid rgba(255, 255, 255, 0.12)';
            }
        });
        this.perkMenuIndex = safeIndex;
        const panel = this._el.perkPanel;
        const selected = this.perkButtons[safeIndex];
        if (panel && selected) {
            const itemTop = selected.offsetTop;
            const itemBottom = itemTop + selected.offsetHeight;
            if (itemTop < panel.scrollTop) {
                panel.scrollTop = itemTop - 6;
            } else if (itemBottom > panel.scrollTop + panel.clientHeight) {
                panel.scrollTop = itemBottom - panel.clientHeight + 6;
            }
        }
    }

    getPerkMenuSelection() {
        return this.perkMenuIndex ?? 0;
    }

    getPerkMenuValue() {
        if (!this.perkButtons || !this.perkButtons.length) {
            const idx = this.perkMenuIndex ?? 0;
            return this.perkOptions[idx]?.value || null;
        }
        const idx = this.perkMenuIndex ?? 0;
        return this.perkButtons[idx]?.getAttribute('data-perk') || null;
    }

    updateAmmo(weapon) {
        const ammoInfo = this._el.ammoInfo;
        if (!ammoInfo) return;
        if (!weapon || weapon.type === 'fists') {
            const newText = '';
            if (this._lastState.ammoText === newText) return;
            this._lastState.ammoText = newText;
            ammoInfo.textContent = '';
            return;
        }
        const name = this.t.weapons[weapon.type] || weapon.type;
        const val = weapon.type === 'knife' ? (weapon.durability ?? 0) : (weapon.ammo ?? 0);
        const newText = `${name}: ${val}`;
        if (this._lastState.ammoText === newText) return;
        this._lastState.ammoText = newText;
        ammoInfo.textContent = newText;
    }

    updateMinimap(data = {}) {
        const ctx = this.minimapCtx;
        const canvas = this.minimapCanvas;
        if (!ctx || !canvas) return;
        const size = canvas.width;
        const half = size * 0.5;
        const mapSize = Math.max(1, data.mapSize || 1);
        const scale = size / mapSize;
        const toMap = (x = 0, z = 0) => ({
            x: half + x * scale,
            y: half + z * scale
        });

        ctx.clearRect(0, 0, size, size);
        ctx.fillStyle = 'rgba(10, 18, 26, 0.92)';
        ctx.fillRect(0, 0, size, size);

        ctx.strokeStyle = 'rgba(255,255,255,0.08)';
        ctx.lineWidth = Math.max(1, size * 0.005);
        for (let i = 1; i < 4; i++) {
            const p = (size / 4) * i;
            ctx.beginPath();
            ctx.moveTo(p, 0);
            ctx.lineTo(p, size);
            ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(0, p);
            ctx.lineTo(size, p);
            ctx.stroke();
        }

        const zoneRadius = Math.max(0, data.zoneRadius || 0) * scale;
        if (zoneRadius > 1) {
            ctx.beginPath();
            if (data.zoneShape === 'square') {
                ctx.rect(half - zoneRadius, half - zoneRadius, zoneRadius * 2, zoneRadius * 2);
            } else {
                ctx.arc(half, half, zoneRadius, 0, Math.PI * 2);
            }
            ctx.fillStyle = 'rgba(38, 140, 255, 0.08)';
            ctx.fill();
            ctx.strokeStyle = 'rgba(96, 190, 255, 0.95)';
            ctx.lineWidth = Math.max(2, size * 0.008);
            ctx.stroke();
        }

        const drawDot = (x, z, color, r) => {
            const p = toMap(x, z);
            if (p.x < 0 || p.y < 0 || p.x > size || p.y > size) return;
            ctx.beginPath();
            ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
            ctx.fillStyle = color;
            ctx.fill();
        };

        const botR = Math.max(1.8, size * 0.012);
        const zombieR = Math.max(1.5, size * 0.01);
        const playerR = Math.max(2.4, size * 0.0145);
        const bots = data.bots || [];
        const zombies = data.zombies || [];
        for (let i = 0; i < bots.length; i++) {
            const b = bots[i];
            drawDot(b.x, b.z, '#ffcf33', botR);
        }
        for (let i = 0; i < zombies.length; i++) {
            const z = zombies[i];
            drawDot(z.x, z.z, '#ff4b4b', zombieR);
        }
        if (data.player) {
            drawDot(data.player.x, data.player.z, '#3cff7a', playerR);
        }
    }
}

