import * as THREE from 'three';
import { Inventory } from '../items/Inventory.js';
import { Weapon } from '../items/Weapon.js';
import { spawnDamagePopup } from './DamagePopup.js';

export class Player {
    constructor(scene, camera, input) {
        this.scene = scene;
        this.camera = camera;
        this.input = input;

        this.position = new THREE.Vector3(0, 5, 0);
        this.rotation = new THREE.Euler(0, 0, 0);
        this.physics = {
            velocity: new THREE.Vector3(0, 0, 0),
            onGround: false,
            height: 1.7,
            radius: 0.4,
            speed: 8
        };

        this.health = 100;
        this.maxHealth = 100;
        this.armor = 0;
        this.maxArmor = 100;
        this.isInvulnerable = false;
        this.isAlive = true;

        this.inventory = new Inventory();
        this.currentWeapon = null;
        this.fists = new Weapon('fists', this.scene);

        this.mesh = this.createMesh();
        this.scene.add(this.mesh);

        this.fpArms = this.createFirstPersonArms();
        this.camera.add(this.fpArms);
        this.setupViewModel(this.fpArms);
        this.fpArms.visible = false;
        this.viewWeapon = null;
        this.viewWeaponType = null;
        this.viewWeaponBase = null;
        this.viewKick = 0;
        this.punchTime = 0;
        this.punchDuration = 0.25;
        this.weaponSwingTime = 0;
        this.weaponSwingDuration = 0.2;
        this.weaponActionTime = 0;
        this.weaponActionDuration = 0.18;
        this.weaponActionType = null;
        this.audioSynthRef = null;

        this.cameraOffset = new THREE.Vector3(0, 1.5, 0);
        this.mouseSensitivity = 0.001;
        this.mobileLookSensitivity = 0.003;
        this.lastLookSide = 0;
        this.euler = new THREE.Euler(0, 0, 0, 'YXZ');

        this.animationState = 'idle';
        this.lastFootstepTime = 0;
        this.coyoteTime = 0;
        this.coyoteDuration = 0.12;
        this.jumpBufferTime = 0;
        this.jumpBufferDuration = 0.12;
        this.slowTimer = 0;
        this.slowFactor = 1;
        this.attackCooldown = 0;
        this.attackSpeedMultiplier = 1;
        this.footstepVolume = 1;
        this.perk = null;
        this.perkAmmoBonus = 1;
        this.isSilent = false;
        this.damageReduction = 0;
        this.recoilScale = 1;
        this.autoFire = false;
        this.baseSpeed = this.physics.speed;
        this.damageTakenMultiplier = 0.55;
        this.stats = { damage: 0, kills: 0, loot: 0 };
        this.hudRef = null;
        this.cameraShakeTime = 0;
        this.cameraShakeDuration = 0.12;
        this.cameraShakeStrength = 0.035;
        this.trailCooldown = 0;
        this.burnTimer = 0;
        this.burnTickTimer = 0;
        this.burnDamagePerSecond = 0;
        this.burnAttacker = null;
        this.lastFlashTime = 0;
    }

    resetView() {
        this.rotation.set(0, 0, 0);
        if (this.input && this.input.resetLook) {
            this.input.resetLook();
        }
        this.camera.rotation.set(0, 0, 0, 'YXZ');
        this.camera.quaternion.setFromEuler(this.camera.rotation);
    }

    createFirstPersonArms() {
        const group = new THREE.Group();
        const armMat = new THREE.MeshStandardMaterial({
            color: 0x2f5d8f,
            roughness: 0.35,
            metalness: 0.0,
            flatShading: true
        });
        const handMat = new THREE.MeshStandardMaterial({
            color: 0xffc9a6,
            roughness: 0.4,
            metalness: 0.0,
            flatShading: true
        });
        const cuffMat = new THREE.MeshStandardMaterial({
            color: 0x2f3e55,
            roughness: 0.5,
            metalness: 0.0,
            flatShading: true
        });

        const leftArm = new THREE.Mesh(
            new THREE.BoxGeometry(0.18, 0.24, 0.18),
            armMat
        );
        leftArm.position.set(-0.34, -0.56, -0.86);
        group.add(leftArm);
        const leftCuff = new THREE.Mesh(
            new THREE.BoxGeometry(0.18, 0.06, 0.18),
            cuffMat
        );
        leftCuff.position.set(-0.34, -0.7, -0.86);
        group.add(leftCuff);

        const rightArm = new THREE.Mesh(
            new THREE.BoxGeometry(0.18, 0.24, 0.18),
            armMat
        );
        rightArm.position.set(0.34, -0.56, -0.86);
        group.add(rightArm);
        const rightCuff = new THREE.Mesh(
            new THREE.BoxGeometry(0.18, 0.06, 0.18),
            cuffMat
        );
        rightCuff.position.set(0.34, -0.7, -0.86);
        group.add(rightCuff);

        const leftHand = new THREE.Mesh(
            new THREE.BoxGeometry(0.18, 0.16, 0.18),
            handMat
        );
        leftHand.position.set(-0.34, -0.66, -0.98);
        group.add(leftHand);

        const rightHand = new THREE.Mesh(
            new THREE.BoxGeometry(0.18, 0.16, 0.18),
            handMat
        );
        rightHand.position.set(0.34, -0.66, -0.98);
        group.add(rightHand);

        group.userData.limbs = { leftArm, rightArm, leftHand, rightHand };
        group.userData.base = {
            leftArm: leftArm.position.clone(),
            rightArm: rightArm.position.clone(),
            leftHand: leftHand.position.clone(),
            rightHand: rightHand.position.clone()
        };

        group.scale.setScalar(1.0);
        return group;
    }

    setupViewModel(object) {
        object.traverse(child => {
            if (child.isMesh) {
                child.renderOrder = 999;
                child.frustumCulled = false;
                if (child.material) {
                    child.material.depthTest = false;
                    child.material.depthWrite = false;
                }
            }
        });
    }

    createMesh() {
        const group = new THREE.Group();

        const bodyMat = new THREE.MeshStandardMaterial({
            color: 0x4a90e2,
            roughness: 0.35,
            metalness: 0.0,
            flatShading: true
        });
        const body = new THREE.Mesh(
            new THREE.BoxGeometry(0.8, 1.0, 0.6),
            bodyMat
        );
        body.position.y = 0.85;
        group.add(body);

        const headMat = new THREE.MeshStandardMaterial({
            color: 0xffd6b5,
            roughness: 0.4,
            metalness: 0.0,
            flatShading: true
        });
        const head = new THREE.Mesh(
            new THREE.BoxGeometry(0.7, 0.7, 0.7),
            headMat
        );
        head.position.y = 1.65;
        group.add(head);

        const armMat = new THREE.MeshStandardMaterial({
            color: 0x3f6fa1,
            roughness: 0.35,
            metalness: 0.0,
            flatShading: true
        });
        const leftArm = new THREE.Mesh(
            new THREE.BoxGeometry(0.28, 0.9, 0.28),
            armMat
        );
        leftArm.position.set(-0.54, 0.7, 0);
        group.add(leftArm);

        const rightArm = new THREE.Mesh(
            new THREE.BoxGeometry(0.28, 0.9, 0.28),
            armMat
        );
        rightArm.position.set(0.54, 0.7, 0);
        group.add(rightArm);

        const handMat = new THREE.MeshStandardMaterial({
            color: 0xffc9a6,
            roughness: 0.4,
            metalness: 0.0,
            flatShading: true
        });
        const leftHand = new THREE.Mesh(
            new THREE.BoxGeometry(0.26, 0.2, 0.26),
            handMat
        );
        leftHand.position.set(-0.54, 0.2, 0);
        group.add(leftHand);
        const rightHand = new THREE.Mesh(
            new THREE.BoxGeometry(0.26, 0.2, 0.26),
            handMat
        );
        rightHand.position.set(0.54, 0.2, 0);
        group.add(rightHand);

        const weaponSocket = new THREE.Object3D();
        weaponSocket.position.set(0.62, 1.1, 0.2);
        weaponSocket.rotation.set(0, Math.PI / 2, 0);
        group.add(weaponSocket);

        const legMat = new THREE.MeshStandardMaterial({
            color: 0x1a1a1a,
            roughness: 0.5,
            metalness: 0.0,
            flatShading: true
        });
        const leftLeg = new THREE.Mesh(
            new THREE.BoxGeometry(0.32, 0.9, 0.32),
            legMat
        );
        leftLeg.position.set(-0.2, 0.3, 0);
        group.add(leftLeg);

        const rightLeg = new THREE.Mesh(
            new THREE.BoxGeometry(0.32, 0.9, 0.32),
            legMat
        );
        rightLeg.position.set(0.2, 0.3, 0);
        group.add(rightLeg);

        group.userData.isEntity = true;
        group.userData.isPlayer = true;
        group.userData.limbs = { leftArm, rightArm, leftLeg, rightLeg };
        group.userData.weaponSocket = weaponSocket;
        return group;
    }

    update(delta, audioSynth, lootManager, entityManager, controls) {
        if (!this.isAlive) return;
        this.audioSynthRef = audioSynth;
        this.updateBurning(delta);
        if (this.trailCooldown > 0) {
            this.trailCooldown = Math.max(0, this.trailCooldown - delta);
        }
        if (this.attackCooldown > 0) {
            this.attackCooldown = Math.max(0, this.attackCooldown - delta);
        }

        if (controls && controls.isLocked) {
            this.euler.setFromQuaternion(controls.getObject().quaternion, 'YXZ');
            this.rotation.y = Number.isFinite(this.euler.y) ? this.euler.y : this.rotation.y;
            this.rotation.x = Number.isFinite(this.euler.x) ? this.euler.x : this.rotation.x;
            this.rotation.z = 0;
            const maxPitch = Math.PI / 2.4;
            this.rotation.x = Math.max(-maxPitch, Math.min(maxPitch, this.rotation.x));
        } else {
            const look = this.input.getLookDelta();
            if (look.x !== 0 || look.y !== 0) {
                const maxDelta = 90;
                const dx = Math.max(-maxDelta, Math.min(maxDelta, look.x));
                const dy = Math.max(-maxDelta, Math.min(maxDelta, look.y));
                if (this.input.isMobile) {
                    const side = Math.max(window.innerWidth, window.innerHeight);
                    if (side !== this.lastLookSide) {
                        this.lastLookSide = side;
                        this.mobileLookSensitivity = 5.7 / side;
                    }
                }
                const sensitivity = this.input.isMobile ? this.mobileLookSensitivity : this.mouseSensitivity * 1.4;
                this.rotation.y -= dx * sensitivity;
                this.rotation.x -= dy * sensitivity;
                const maxPitch = Math.PI / 2.4;
                this.rotation.x = Math.max(-maxPitch, Math.min(maxPitch, this.rotation.x));
            }
        }
        if (!Number.isFinite(this.rotation.x) || !Number.isFinite(this.rotation.y)) {
            this.rotation.set(0, 0, 0);
        }

        const isFrozen = this.isFrozen === true;
        const moveVector = isFrozen ? new THREE.Vector3() : this.input.getMovementVector();
        if (this.slowTimer > 0) {
            this.slowTimer = Math.max(0, this.slowTimer - delta);
        } else {
            this.slowFactor = 1;
        }

        if (isFrozen) {
            this.physics.velocity.x = 0;
            this.physics.velocity.z = 0;
        }
        if (moveVector.length() > 0) {
            let moveDirection = new THREE.Vector3();

            if (controls && controls.isLocked) {
                const cameraDirection = new THREE.Vector3();
                controls.getObject().getWorldDirection(cameraDirection);
                cameraDirection.y = 0;
                cameraDirection.normalize();

                const rightDirection = new THREE.Vector3();
                rightDirection.crossVectors(cameraDirection, new THREE.Vector3(0, 1, 0));

                moveDirection.addScaledVector(cameraDirection, -moveVector.z);
                moveDirection.addScaledVector(rightDirection, moveVector.x);
                moveDirection.normalize();
            } else {
                const cameraDirection = new THREE.Vector3();
                this.camera.getWorldDirection(cameraDirection);
                cameraDirection.y = 0;
                cameraDirection.normalize();

                const rightDirection = new THREE.Vector3();
                rightDirection.crossVectors(cameraDirection, new THREE.Vector3(0, 1, 0));

                moveDirection.addScaledVector(cameraDirection, -moveVector.z);
                moveDirection.addScaledVector(rightDirection, moveVector.x);
                moveDirection.normalize();
            }

            const speed = this.physics.speed * this.slowFactor;
            this.physics.velocity.x = moveDirection.x * speed;
            this.physics.velocity.z = moveDirection.z * speed;

            const currentTime = performance.now() / 1000;
            if (this.physics.onGround && currentTime - this.lastFootstepTime > 0.5 && audioSynth) {
                audioSynth.playFootstep(this.footstepVolume);
                this.lastFootstepTime = currentTime;
            }

            this.animationState = 'walking';
        } else {
            this.physics.velocity.x *= 0.8;
            this.physics.velocity.z *= 0.8;
            this.animationState = 'idle';
        }

        if (this.perk === 'fastRun' && entityManager && moveVector.length() > 0.2 && this.trailCooldown === 0) {
            const trailPos = this.position.clone();
            trailPos.y = 0.4;
            entityManager.spawnSpeedTrail?.(trailPos, 0x4bb3ff);
            this.trailCooldown = 0.08;
        }

        if (!isFrozen && this.input.isKeyPressed('Space')) {
            this.jumpBufferTime = this.jumpBufferDuration;
        }

        if (this.physics.onGround) {
            this.coyoteTime = this.coyoteDuration;
        } else {
            this.coyoteTime = Math.max(0, this.coyoteTime - delta);
        }

        if (!isFrozen && this.jumpBufferTime > 0) {
            if (this.physics.onGround || this.coyoteTime > 0) {
                this.physics.velocity.y = 10.2;
                this.physics.onGround = false;
                this.jumpBufferTime = 0;
                this.coyoteTime = 0;
            }
        }
        this.jumpBufferTime = Math.max(0, this.jumpBufferTime - delta);

        this.mesh.position.copy(this.position);
        this.mesh.position.y = this.position.y - (this.physics.height - 0.15);
        this.mesh.rotation.y = this.rotation.y;
        this.animateLimbs();

        const cameraPosition = new THREE.Vector3(
            Math.round(this.position.x * 100) / 100,
            this.position.y + this.cameraOffset.y,
            Math.round(this.position.z * 100) / 100
        );
        const shakeOffset = new THREE.Vector3();
        if (this.cameraShakeTime > 0) {
            const t = this.cameraShakeTime / this.cameraShakeDuration;
            const strength = this.cameraShakeStrength * t;
            shakeOffset.set(
                (Math.random() - 0.5) * strength,
                (Math.random() - 0.5) * strength,
                (Math.random() - 0.5) * strength
            );
            this.cameraShakeTime = Math.max(0, this.cameraShakeTime - delta);
        }

        if (controls && controls.isLocked) {
            controls.getObject().position.copy(cameraPosition.clone().add(shakeOffset));
            controls.getObject().position.y = this.position.y + this.cameraOffset.y;
            if (this.lastCameraPosition) {
                const dist = cameraPosition.distanceTo(this.lastCameraPosition);
                if (dist < 0.05) {
                    controls.getObject().position.copy(this.lastCameraPosition);
                } else {
                    this.lastCameraPosition.copy(cameraPosition);
                }
            } else {
                this.lastCameraPosition = cameraPosition.clone();
            }
        } else {
            this.camera.position.copy(cameraPosition.clone().add(shakeOffset));
            this.camera.rotation.set(this.rotation.x, this.rotation.y, 0, 'YXZ');
            this.camera.up.set(0, 1, 0);
        }

        const isFirstPerson = (controls && controls.isLocked) || this.input.isMobile;
        if (isFirstPerson) {
            this.mesh.visible = false;
            this.fpArms.visible = true;
            if (this.currentWeapon) this.currentWeapon.setVisible(false);
        } else {
            this.mesh.visible = true;
            this.fpArms.visible = false;
            if (this.currentWeapon) this.currentWeapon.setVisible(true);
        }
        this.updateFirstPersonArmsVisibility(isFirstPerson);
        this.animateViewModel(isFirstPerson);

        for (let i = 0; i <= 9; i++) {
            if (this.input.isKeyPressed(`Digit${i}`) || this.input.isKeyPressed(`Numpad${i}`)) {
                this.selectSlot(i);
            }
        }

        const activeWeapon = this.currentWeapon || this.fists;
        const autoTarget = this.autoFire ? this.getAutoFireTarget(entityManager) : null;
        const isRangedWeapon = ['bow', 'laser', 'shotgun', 'flamethrower', 'pistol', 'rifle'].includes(activeWeapon.type);
        const fireRequested = this.input.isKeyPressed('MouseLeft') || (!!autoTarget && !isFrozen && isRangedWeapon);
        if (!isFrozen && fireRequested && this.attackCooldown <= 0) {
            if (activeWeapon.type === 'bow' || activeWeapon.type === 'laser' || activeWeapon.type === 'shotgun' || activeWeapon.type === 'flamethrower' || activeWeapon.type === 'pistol' || activeWeapon.type === 'rifle') {
                const direction = new THREE.Vector3();
                if (autoTarget) {
                    direction.subVectors(autoTarget.position, this.camera.position).normalize();
                } else {
                    this.camera.getWorldDirection(direction);
                }
                const result = activeWeapon.attack(this, null, audioSynth, direction);
                const muzzle = new THREE.Vector3();
                this.camera.getWorldPosition(muzzle);
                muzzle.add(direction.clone().multiplyScalar(0.6));

                if (result && result.projectiles) {
                    for (const proj of result.projectiles) {
                        proj.owner = this;
                        proj.mesh.position.copy(muzzle);
                        entityManager.addProjectile(proj);
                    }
                } else if (result && result.projectile) {
                    result.projectile.direction = direction;
                    result.projectile.owner = this;
                    result.projectile.mesh.position.copy(muzzle);
                    if (result.projectile.velocity) {
                        result.projectile.velocity.copy(direction).multiplyScalar(result.projectile.speed);
                    }
                    result.projectile.mesh.lookAt(muzzle.clone().add(direction));
                    entityManager.addProjectile(result.projectile);
                }
                this.viewKick = 0.25 * this.recoilScale;
                this.weaponActionTime = this.weaponActionDuration;
                this.weaponActionType = activeWeapon.type;
            } else {
                const target = entityManager.getNearestEnemy(this.position, activeWeapon.range);
                if (target) {
                    const result = activeWeapon.attack(this, target, audioSynth);
                    if (result && result.hit) {
                        target.takeDamage(result.damage, result.isHeadshot, this, result.knockback || 0);
                        this.viewKick = 0.3 * this.recoilScale;
                        this.onHit();
                    }
                }
            }
            if (activeWeapon.type === 'fists') {
                if (this.punchTime <= 0) {
                    this.punchTime = this.punchDuration;
                }
            }
            if (activeWeapon.type === 'knife' || activeWeapon.type === 'axe' || activeWeapon.type === 'spear') {
                if (this.weaponSwingTime <= 0) {
                    this.weaponSwingTime = this.weaponSwingDuration;
                }
            }
            this.attackCooldown = activeWeapon.cooldown * this.attackSpeedMultiplier;
        }

        if (!isFrozen && this.input.isKeyPressed('KeyE')) {
            const nearestChest = lootManager.getChests().find(chest => {
                if (chest.userData.isOpen) return false;
                return this.position.distanceTo(chest.position) < 3;
            });

            if (nearestChest) {
                const loot = lootManager.tryOpenChest(nearestChest, this, audioSynth);
                if (loot) {
                    this.pickupLoot(loot);
                }
            }
        }

        lootManager.checkNearbyChests(this.position, audioSynth);

        if (!isFirstPerson && this.currentWeapon && this.currentWeapon.mesh) {
            this.updateThirdPersonWeapon();
        }
        this.punchTime = Math.max(0, this.punchTime - delta);
        this.weaponSwingTime = Math.max(0, this.weaponSwingTime - delta);
        this.weaponActionTime = Math.max(0, this.weaponActionTime - delta);
        if (this.weaponActionTime === 0) {
            this.weaponActionType = null;
        }
        this.viewKick = Math.max(0, this.viewKick - delta * 6);
    }

    animateLimbs() {
        const limbs = this.mesh?.userData?.limbs;
        if (!limbs) return;

        const speed = Math.sqrt(
            this.physics.velocity.x * this.physics.velocity.x +
            this.physics.velocity.z * this.physics.velocity.z
        );
        const speedNorm = Math.min(1, speed / this.physics.speed);
        const time = performance.now() / 1000;

        if (speedNorm > 0.05) {
            const swing = Math.sin(time * 10) * 0.8 * speedNorm;
            limbs.leftArm.rotation.x = swing;
            limbs.rightArm.rotation.x = -swing;
            limbs.leftLeg.rotation.x = -swing;
            limbs.rightLeg.rotation.x = swing;
        } else {
            const idle = Math.sin(time * 2) * 0.08;
            limbs.leftArm.rotation.x = idle;
            limbs.rightArm.rotation.x = -idle;
            limbs.leftLeg.rotation.x = -idle;
            limbs.rightLeg.rotation.x = idle;
        }
    }

    animateViewModel(isFirstPerson) {
        if (!isFirstPerson) {
            if (this.viewWeapon) this.viewWeapon.visible = false;
            return;
        }

        if (this.viewWeapon) this.viewWeapon.visible = true;

        const arms = this.fpArms?.userData?.limbs;
        if (!arms) return;

        const swing = Math.sin(performance.now() * 0.01) * 0.02;
        arms.leftArm.position.copy(this.fpArms.userData.base.leftArm);
        arms.rightArm.position.copy(this.fpArms.userData.base.rightArm);
        arms.leftHand.position.copy(this.fpArms.userData.base.leftHand);
        arms.rightHand.position.copy(this.fpArms.userData.base.rightHand);

        const bob = Math.sin(performance.now() * 0.008) * 0.03;
        arms.leftArm.position.y += bob;
        arms.rightArm.position.y += bob;
        arms.leftHand.position.y += bob;
        arms.rightHand.position.y += bob;

        if (this.punchTime > 0) {
            const t = 1 - this.punchTime / this.punchDuration;
            const punch = Math.sin(t * Math.PI) * 0.25;
            arms.rightArm.position.z += punch;
            arms.rightHand.position.z += punch;
        }

        if (this.viewWeapon && this.viewWeapon.visible) {
            if (this.viewWeaponBase) {
                this.viewWeapon.position.copy(this.viewWeaponBase.position);
                this.viewWeapon.rotation.copy(this.viewWeaponBase.rotation);
            }

            if ((this.viewWeaponType === 'knife' || this.viewWeaponType === 'axe' || this.viewWeaponType === 'spear') && this.weaponSwingTime > 0) {
                const t = 1 - this.weaponSwingTime / this.weaponSwingDuration;
                const swing = Math.sin(t * Math.PI);
                const swingMul = this.viewWeaponType === 'axe' ? 0.75 : this.viewWeaponType === 'spear' ? 0.45 : 0.6;
                this.viewWeapon.rotation.z -= swing * swingMul;
                this.viewWeapon.position.z -= swing * 0.08;
            }

            if ((this.viewWeaponType === 'bow' || this.viewWeaponType === 'laser' || this.viewWeaponType === 'shotgun' || this.viewWeaponType === 'pistol' || this.viewWeaponType === 'rifle' || this.viewWeaponType === 'flamethrower') && this.viewKick > 0) {
                this.viewWeapon.position.z -= this.viewKick * 0.2;
                this.viewWeapon.rotation.x -= this.viewKick * 0.6;
            }

            if (this.weaponActionTime > 0 && this.weaponActionType) {
                const t = 1 - this.weaponActionTime / this.weaponActionDuration;
                const ease = Math.sin(t * Math.PI);
                if (this.weaponActionType === 'bow') {
                    this.viewWeapon.position.z -= ease * 0.09;
                    this.viewWeapon.position.x -= ease * 0.03;
                    this.viewWeapon.rotation.y += ease * 0.06;
                } else if (this.weaponActionType === 'laser' || this.weaponActionType === 'shotgun' || this.weaponActionType === 'pistol' || this.weaponActionType === 'rifle' || this.weaponActionType === 'flamethrower') {
                    this.viewWeapon.position.z -= ease * 0.1;
                    this.viewWeapon.rotation.x -= ease * 0.35;
                }
            }
        }
    }

    updateFirstPersonArmsVisibility(isFirstPerson) {
        if (!this.fpArms) return;
        if (!isFirstPerson) return;
        const limbs = this.fpArms.userData?.limbs;
        if (!limbs) return;
        const weaponType = this.currentWeapon?.type || 'fists';
        const showArms = weaponType === 'fists';
        limbs.leftArm.visible = showArms;
        limbs.rightArm.visible = showArms;
        limbs.leftHand.visible = showArms;
        limbs.rightHand.visible = showArms;
    }

    selectSlot(slot) {
        const weapon = this.inventory.selectSlot(slot);
        if (this.currentWeapon) {
            this.currentWeapon.setVisible(false);
        }

        if (weapon) {
            this.currentWeapon = weapon;
            this.currentWeapon.setVisible(true);
        } else {
            this.currentWeapon = null;
            this.fists = new Weapon('fists', this.scene);
        }
        this.updateViewWeapon();
    }

    pickupLoot(loot) {
        if (loot.type === 'weapon') {
            const weapon = new Weapon(loot.weaponType, this.scene);
            this.applyWeaponPerk(weapon);
            const result = this.inventory.addItem(weapon);
            if (result.added) {
                if (!this.currentWeapon || !this.inventory.getSelectedWeapon()) {
                    this.selectSlot(result.slot);
                }
            } else {
                weapon.dispose();
            }
            this.updateViewWeapon();
        } else if (loot.type === 'armor') {
            this.armor = Math.min(this.maxArmor, this.armor + loot.amount);
        } else if (loot.type === 'ammo') {
            const amount = loot.amount || 0;
            if (amount > 0) {
                const candidates = this.inventory.getItems().filter(w => w && w.ammo !== null);
                const target = this.currentWeapon && this.currentWeapon.ammo !== null
                    ? this.currentWeapon
                    : candidates[0];
                if (target) {
                    target.ammo = Math.min(target.maxAmmo ?? target.ammo, (target.ammo ?? 0) + amount);
                }
            }
        }
        this.stats.loot += 1;
    }

    takeDamage(damage, isHeadshot = false, attacker = null, knockbackStrength = 0, source = null) {
        if (this.isInvulnerable) return false;

        const finalDamage = (isHeadshot ? damage * 2 : damage) * (1 - this.damageReduction) * this.damageTakenMultiplier;
        if (attacker?.stats) {
            attacker.stats.damage += finalDamage;
        }

        if (this.armor > 0) {
            const armorDamage = Math.min(this.armor, finalDamage);
            this.armor -= armorDamage;
            const remainingDamage = finalDamage - armorDamage;

            if (remainingDamage > 0) {
                this.health -= remainingDamage;
            }
        } else {
            this.health -= finalDamage;
        }

        if (this.health <= 0) {
            this.health = 0;
            this.isAlive = false;
            this.isFrozen = true;
            this.physics.velocity.set(0, 0, 0);
            this.mesh.position.copy(this.position);
            this.mesh.position.y = this.position.y - (this.physics.height - 0.15) - 0.8;
            this.mesh.rotation.set(-Math.PI / 2, this.rotation.y, 0);
            if (attacker?.stats) {
                attacker.stats.kills += 1;
            }
            this.clearBurning();
        }
        const isDotDamage = source === 'zone' || source === 'storm' || source === 'burn' || source === 'trap';
        if (!isDotDamage) {
            this.flashDamage();
            spawnDamagePopup(this.scene, this.position, finalDamage, { color: '#ff5b5b', key: 'player' });
        }
        if (source === 'flame' && this.isAlive) {
            this.applyBurn(2.2, 4.2, attacker);
        }
        if (this.audioSynthRef) {
            if (source === 'zone' && this.audioSynthRef.playZoneDamage) {
                this.audioSynthRef.playZoneDamage();
            } else if (this.audioSynthRef.playHurt) {
                this.audioSynthRef.playHurt();
            }
        }
        if (attacker && this.isAlive) {
            const strength = knockbackStrength > 0 ? knockbackStrength : 3;
            const dir = new THREE.Vector3().subVectors(this.position, attacker.position).normalize();
            this.physics.velocity.x += dir.x * strength;
            this.physics.velocity.z += dir.z * strength;
            this.physics.velocity.y += 2;
        }

        return true;
    }

    onHit() {
        if (this.hudRef?.showHitMarker) {
            this.hudRef.showHitMarker();
        }
        this.cameraShakeTime = this.cameraShakeDuration;
    }

    setHUD(hud) {
        this.hudRef = hud;
    }

    applyPerk(perk, baseFootstep = 1) {
        this.perk = perk;
        this.attackSpeedMultiplier = 1;
        this.footstepVolume = baseFootstep;
        this.perkAmmoBonus = 1;
        this.isSilent = false;
        this.damageReduction = 0;
        this.recoilScale = 1;
        this.autoFire = false;
        this.physics.speed = this.baseSpeed;

        if (perk === 'quickHands') {
            this.attackSpeedMultiplier = 0.75;
        } else if (perk === 'silentStep') {
            this.footstepVolume = Math.min(0.35, baseFootstep);
            this.isSilent = true;
        } else if (perk === 'moreAmmo') {
            this.perkAmmoBonus = 1.35;
        } else if (perk === 'fastRun') {
            this.physics.speed = this.baseSpeed * 1.35;
        } else if (perk === 'thickSkin') {
            this.damageReduction = 0.2;
        } else if (perk === 'steadyAim') {
            this.recoilScale = 0.6;
        } else if (perk === 'autoFire') {
            this.autoFire = true;
        }

        if (this.fists) {
            this.fists.cooldown *= this.attackSpeedMultiplier;
        }
    }

    applyWeaponPerk(weapon) {
        if (!weapon) return;
        if (this.perk === 'quickHands') {
            weapon.cooldown *= this.attackSpeedMultiplier;
        }
        if (this.perk === 'moreAmmo') {
            if (weapon.maxAmmo !== null) {
                weapon.maxAmmo = Math.round(weapon.maxAmmo * this.perkAmmoBonus);
                weapon.ammo = weapon.maxAmmo;
            }
            if (weapon.maxDurability !== null) {
                weapon.maxDurability = Math.round(weapon.maxDurability * this.perkAmmoBonus);
                weapon.durability = weapon.maxDurability;
            }
        }
    }

    setInvulnerable(value) {
        this.isInvulnerable = value;
    }

    flashDamage() {
        if (!this.mesh) return;
        const now = performance.now();
        if (now - this.lastFlashTime < 90) return;
        this.lastFlashTime = now;
        this.mesh.traverse((child) => {
            if (child.isMesh) {
                child.material.emissive = new THREE.Color(0xff0000);
                child.material.emissiveIntensity = 0.5;
                setTimeout(() => {
                    if (child.material) {
                        child.material.emissiveIntensity = 0;
                    }
                }, 200);
            }
        });
    }

    applyBurn(duration = 2, damagePerSecond = 4, attacker = null) {
        this.burnTimer = Math.max(this.burnTimer, duration);
        this.burnTickTimer = Math.max(this.burnTickTimer, 0.08);
        this.burnDamagePerSecond = Math.max(this.burnDamagePerSecond, damagePerSecond);
        if (attacker) this.burnAttacker = attacker;
    }

    clearBurning() {
        this.burnTimer = 0;
        this.burnTickTimer = 0;
        this.burnDamagePerSecond = 0;
        this.burnAttacker = null;
        this.setBurnVisual(0);
    }

    updateBurning(delta) {
        if (this.burnTimer <= 0 || !this.isAlive) return;

        this.burnTimer = Math.max(0, this.burnTimer - delta);
        this.burnTickTimer -= delta;
        const pulse = 0.18 + Math.sin(performance.now() * 0.03) * 0.08;
        this.setBurnVisual(Math.max(0.1, pulse));

        while (this.burnTickTimer <= 0 && this.isAlive) {
            const tickDamage = this.burnDamagePerSecond * 0.25;
            this.takeDamage(tickDamage, false, this.burnAttacker, 0, 'burn');
            this.burnTickTimer += 0.25;
        }

        if (this.burnTimer <= 0) {
            this.clearBurning();
        }
    }

    setBurnVisual(intensity) {
        if (!this.mesh) return;
        this.mesh.traverse(child => {
            if (!child.material || !child.material.emissive) return;
            child.material.emissive.setHex(0xff6d00);
            child.material.emissiveIntensity = intensity;
        });
    }

    animateViewModelWeapon(weaponType) {
        if (!this.fpArms) return;

        if (this.viewWeapon) {
            this.fpArms.remove(this.viewWeapon);
            this.viewWeapon = null;
            this.viewWeaponBase = null;
        }

        this.viewWeaponType = weaponType || null;
        if (!weaponType || weaponType === 'fists') return;

        const source = new Weapon(weaponType, this.scene);
        if (!source.mesh) return;
        const viewClone = source.mesh.clone();
        this.scene.remove(source.mesh);
        viewClone.visible = true;
        const offset = this.getViewWeaponOffset(weaponType);
        viewClone.scale.setScalar(offset.scale);
        viewClone.position.copy(offset.position);
        viewClone.rotation.copy(offset.rotation);
        this.setupViewModel(viewClone);
        this.fpArms.add(viewClone);
        this.viewWeapon = viewClone;
        this.viewWeaponBase = {
            position: offset.position.clone(),
            rotation: offset.rotation.clone()
        };
    }

    updateViewWeapon() {
        const weapon = this.currentWeapon || this.fists;
        this.animateViewModelWeapon(weapon?.type);
    }

    getViewWeaponOffset(type) {
        const base = {
            scale: 1.1,
            position: new THREE.Vector3(0.18, -0.42, -0.6),
            rotation: new THREE.Euler(0, Math.PI, 0)
        };

        if (type === 'knife') {
            base.position.set(0.22, -0.34, -0.66);
            base.rotation.set(-Math.PI / 2 + 0.12, Math.PI, 0.08);
            base.scale = 1.0;
        } else if (type === 'bow') {
            base.position.set(0.2, -0.22, -1.02);
            base.rotation.set(0.02, Math.PI, Math.PI / 2.2);
            base.scale = 0.68;
        } else if (type === 'axe') {
            base.position.set(0.24, -0.3, -0.74);
            base.rotation.set(-Math.PI / 2 + 0.08, Math.PI, 0.12);
            base.scale = 1.0;
        } else if (type === 'spear') {
            base.position.set(0.2, -0.28, -0.98);
            base.rotation.set(-Math.PI / 2, Math.PI, 0.02);
            base.scale = 1.0;
        } else if (type === 'shotgun') {
            base.position.set(0.26, -0.32, -0.75);
            base.rotation.set(-0.06, Math.PI, Math.PI / 14);
            base.scale = 1.05;
        } else if (type === 'flamethrower') {
            base.position.set(0.26, -0.34, -0.78);
            base.rotation.set(-0.06, Math.PI, Math.PI / 14);
            base.scale = 1.08;
        } else if (type === 'laser') {
            base.position.set(0.24, -0.36, -0.78);
            base.rotation.set(-0.06, Math.PI, Math.PI / 14);
            base.scale = 1.15;
        } else if (type === 'pistol') {
            base.position.set(0.24, -0.34, -0.7);
            base.rotation.set(-0.02, Math.PI, Math.PI / 18);
            base.scale = 1.05;
        } else if (type === 'rifle') {
            base.position.set(0.26, -0.3, -0.86);
            base.rotation.set(-0.04, Math.PI, Math.PI / 16);
            base.scale = 1.1;
        }

        return base;
    }

    updateThirdPersonWeapon() {
        const socket = this.mesh?.userData?.weaponSocket;
        if (!socket || !this.currentWeapon?.mesh) return;
        const worldPos = new THREE.Vector3();
        const worldQuat = new THREE.Quaternion();
        socket.getWorldPosition(worldPos);
        socket.getWorldQuaternion(worldQuat);

        this.currentWeapon.mesh.position.copy(worldPos);
        this.currentWeapon.mesh.quaternion.copy(worldQuat);
    }

    getAutoFireTarget(entityManager) {
        if (!entityManager) return null;
        const forward = new THREE.Vector3();
        this.camera.getWorldDirection(forward);
        const origin = this.camera.position;
        const maxDistance = this.currentWeapon?.range || 60;
        let best = null;
        let bestDist = maxDistance;

        for (const entity of entityManager.getEntities()) {
            if (!entity || !entity.isAlive || entity === this) continue;
            const toTarget = new THREE.Vector3().subVectors(entity.position, origin);
            const dist = toTarget.length();
            if (dist > maxDistance || dist < 1.2) continue;
            toTarget.normalize();
            const dot = forward.dot(toTarget);
            if (dot < 0.988) continue;
            const aimPoint = new THREE.Vector3(
                entity.position.x,
                entity.position.y + (entity.physics?.height || 1.8) * 0.55,
                entity.position.z
            );
            if (typeof entityManager.hasLineOfSight === 'function') {
                const visible = entityManager.hasLineOfSight(origin, aimPoint, true);
                if (!visible) continue;
            }
            if (dist < bestDist) {
                best = entity;
                bestDist = dist;
            }
        }
        return best;
    }

    applySlow(factor, duration) {
        this.slowFactor = Math.min(this.slowFactor, factor);
        this.slowTimer = Math.max(this.slowTimer, duration);
    }

    attack(target, entityManager) {
        let weapon = this.currentWeapon || this.fists;
        if (!weapon || !target || !target.isAlive) return null;

        if ((weapon.type === 'knife' || weapon.type === 'axe' || weapon.type === 'spear') && weapon.durability !== null && weapon.durability <= 0) {
            this.currentWeapon = null;
            weapon = this.fists;
        }
        if ((weapon.type === 'bow' || weapon.type === 'laser' || weapon.type === 'shotgun' || weapon.type === 'flamethrower' || weapon.type === 'pistol' || weapon.type === 'rifle') && weapon.ammo !== null && weapon.ammo <= 0) {
            this.currentWeapon = null;
            weapon = this.fists;
        }

        const distance = this.position.distanceTo(target.position);
        const attackRange = weapon.type === 'laser'
            ? 40
            : weapon.type === 'bow'
                ? 40
                : weapon.type === 'pistol'
                    ? 35
                    : weapon.type === 'rifle'
                        ? 45
                        : weapon.type === 'fists'
                            ? 2.5
                            : 3;

        if (distance > attackRange) return null;

        if (weapon.type === 'laser' || weapon.type === 'bow' || weapon.type === 'shotgun' || weapon.type === 'flamethrower' || weapon.type === 'pistol' || weapon.type === 'rifle') {
            const direction = new THREE.Vector3()
                .subVectors(target.position, this.position)
                .normalize();

            const projectileData = weapon.attack(this, null, null, direction);
            if (projectileData && projectileData.projectiles) {
                for (const proj of projectileData.projectiles) {
                    proj.owner = this;
                    entityManager?.addProjectile(proj);
                }
                return { fired: true, damage: weapon.damage };
            }
            if (projectileData && projectileData.projectile) {
                projectileData.projectile.direction = direction;
                projectileData.projectile.owner = this;
                if (entityManager) {
                    entityManager.addProjectile(projectileData.projectile);
                }
                return { fired: true, damage: weapon.damage };
            }
        } else {
            const result = weapon.attack(this, target);
            if (result && result.hit) {
                target.takeDamage(result.damage, result.isHeadshot, this, result.knockback || 0);
                return { hit: true, damage: result.damage, killed: target.health <= 0 };
            }
        }

        return null;
    }
}
